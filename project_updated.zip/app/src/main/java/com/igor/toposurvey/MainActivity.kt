package com.igor.toposurvey

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 20, 24)
    private val panel = Color.rgb(32, 42, 50)
    private val green = Color.rgb(66, 211, 146)
    private val selCol = Color.rgb(36, 94, 76)

    private class Stamped<T>(val v: T, val at: Long)

    private companion object {
        const val QUICK_COUNT = 12          // 4 columns x 3 rows
        const val MAX_FIX_AGE_MS = 2000L    // a position older than this is never saved
        const val DISPLAY_STALE_MS = 3000L  // top bar shows "--" after this
        const val MAX_POINT = 9999          // Next Point is a 4-digit field
        const val MAX_CODE_LEN = 5
        val QUICK_DEFAULTS = listOf("RE", "CL", "TR", "MH", "FE", "KB", "POLE", "GATE", "S", "LP", "EP", "ST")
    }

    private lateinit var store: SurveyStore
    private var features: List<FeatureCode> = emptyList()
    private val byCode = HashMap<String, FeatureCode>()
    private val quick = ArrayList<String>()
    private val quickButtons = ArrayList<Button>()
    private var selectedCode = "RE"
    private var lineNumber = 1
    private var poleM = 2.0
    private var tipMode = "tip"

    private lateinit var rootView: LinearLayout
    private lateinit var pointField: EditText
    private lateinit var codeField: EditText
    private lateinit var lineValue: TextView
    private lateinit var lineLabel: TextView
    private val lineButtons = ArrayList<Button>()
    private var uiUpdating = false
    private var pending = false
    @Volatile private var ggaInterval = 0L
    private lateinit var gnssBar: GnssBar
    private lateinit var coordLine: TextView
    private lateinit var connLine: TextView
    private lateinit var map: MapView

    @Volatile private var latest: Stamped<GgaFix>? = null
    @Volatile private var gstS: Stamped<GstData>? = null
    @Volatile private var vdopS: Stamped<Double>? = null
    @Volatile private var btState = "BT OFF"
    private val counts = HashMap<String, Int>()
    private val rawLog = ArrayDeque<String>()
    private val gnss = BtGnss({ onLine(it) }, { btState = it })
    @Volatile private var lastGga: String? = null
    @Volatile private var ntripState = "NTRIP OFF"
    private val ntrip = NtripClient({ lastGga }, { b, n -> gnss.write(b, n) }, { ntripState = it })
    private val ui = Handler(Looper.getMainLooper())
    private var diagText: TextView? = null
    private var diagDialog: AlertDialog? = null

    private val tick = object : Runnable {
        override fun run() {
            updateTop()
            updateDiag()
            ui.postDelayed(this, 500)
        }
    }

    /** The whole UI is English regardless of the phone language. */
    override fun attachBaseContext(base: Context) {
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale.ENGLISH)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        store = SurveyStore(this)
        Osgm15.init(this)
        features = runCatching { FxlReader.load(this) }.getOrDefault(emptyList())
        features.forEach { byCode[it.code] = it }
        for (i in 0 until QUICK_COUNT) quick += store.setting("quick_$i", QUICK_DEFAULTS[i])
        selectedCode = store.setting("selected_code", quick[0])
        lineNumber = rememberedLine(selectedCode)
        loadPole()
        render()
        if (features.isEmpty()) toast("FXL could not be read: feature codes unavailable")
        autoConnect()
        startNtrip()
    }

    override fun onResume() { super.onResume(); refreshAll(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
    override fun onDestroy() { super.onDestroy(); gnss.stop(); ntrip.stop() }

    // ---------------- UI ----------------
    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(bg)
            isFocusable = true; isFocusableInTouchMode = true
        }
        rootView = root
        val header = row().apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("TOPO SURVEY", 18, Color.WHITE, true), weight())
        header.addView(smallButton("Menu") { showMenu() })
        root.addView(header)

        gnssBar = GnssBar(this)
        root.addView(gnssBar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        coordLine = label("X --   Y --   Z --", 12, Color.WHITE, true).apply { typeface = Typeface.MONOSPACE; setPadding(0, dp(3), 0, 0) }
        root.addView(coordLine)
        connLine = label("BT OFF · NTRIP OFF", 9, Color.LTGRAY, false)
        root.addView(connLine)

        map = MapView(this, { byCode[it]?.kind ?: "POINT" }, { blockNeedOf(it) }, { id -> store.allPoints().firstOrNull { it.id == id }?.let { showPoint(it) } })
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1.0f).apply { topMargin = dp(6); bottomMargin = dp(6) })

        // Next Point + Current Code: compact editable fields.
        val info = row()
        pointField = EditText(this).apply {
            id = View.generateViewId()
            setSingleLine(); inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(4))
            textSize = 20f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            background = null; setPadding(0, 0, 0, 0); minHeight = 0; minimumHeight = 0
            imeOptions = EditorInfo.IME_ACTION_NEXT
        }
        codeField = EditText(this).apply {
            id = View.generateViewId()
            setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(MAX_CODE_LEN))
            textSize = 20f; setTextColor(green); setTypeface(typeface, Typeface.BOLD)
            background = null; setPadding(0, 0, 0, 0); minHeight = 0; minimumHeight = 0
            imeOptions = EditorInfo.IME_ACTION_DONE
        }
        pointField.nextFocusForwardId = codeField.id
        codeField.nextFocusForwardId = pointField.id
        // Tab / Next on the point field moves to the code field; each field commits its value when it loses focus.
        pointField.setOnFocusChangeListener { _, has -> if (!has) commitPoint() }
        codeField.setOnFocusChangeListener { _, has -> if (!has) commitCode() }
        pointField.setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_NEXT) { codeField.requestFocus(); codeField.selectAll(); true } else false }
        codeField.setOnEditorActionListener { _, _, _ -> leaveFields(); true }
        codeField.setOnKeyListener { _, keyCode, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) { leaveFields(); true } else false
        }
        pointField.setOnKeyListener { _, keyCode, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) { leaveFields(); true } else false
        }
        val pointPanel = cardColumn().apply { addView(label("Next Point", 10, Color.LTGRAY, false)); addView(pointField) }
        val codePanel = cardColumn().apply { addView(label("Current Code", 10, Color.LTGRAY, false)); addView(codeField) }
        info.addView(pointPanel, LinearLayout.LayoutParams(dp(96), dp(56)).apply { rightMargin = dp(6) })
        info.addView(codePanel, LinearLayout.LayoutParams(dp(124), dp(56)))
        root.addView(info)

        val line = row().apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        lineLabel = label("Line", 12, Color.LTGRAY, true)
        line.addView(lineLabel)
        lineButtons.clear()
        lineValue = label("  1  ", 15, Color.WHITE, true)
        line.addView(lineValue, weight())
        val bMinus = smallButton("−") { lineNumber = (lineNumber - 1).coerceAtLeast(1); rememberLine(); refreshValues() }
        val bPlus = smallButton("+") { lineNumber++; rememberLine(); refreshValues() }
        val bSearch = smallButton("Search") { lineNumber = store.firstFreeLine(selectedCode); rememberLine(); refreshValues() }
        for (b in listOf(bMinus, bPlus, bSearch)) { line.addView(b); lineButtons += b }
        root.addView(line)

        root.addView(label("Quick Codes (long press to edit)", 11, Color.LTGRAY, true).apply { setPadding(0, dp(2), 0, dp(3)) })
        val grid = GridLayout(this).apply { columnCount = 4; rowCount = 3 }
        quickButtons.clear()
        for (i in 0 until QUICK_COUNT) {
            val b = Button(this).apply {
                textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); setPadding(0, 0, 0, 0); minWidth = 0; minimumWidth = 0
                setOnClickListener { leaveFields(); if (selectedCode == quick[i]) measure(false) else selectCode(quick[i]) }
                setOnLongClickListener { editQuick(i); true }
            }
            quickButtons += b
            val lp = GridLayout.LayoutParams().apply { width = 0; height = dp(40); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(2), dp(2), dp(2), dp(2)) }
            grid.addView(b, lp)
        }
        root.addView(grid)
        val measureBtn = Button(this).apply {
            text = "MEASURE / SAVE"; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(selCol)
            setOnClickListener { leaveFields(); measure(false) }
            setOnLongClickListener { leaveFields(); measure(true); true }
        }
        root.addView(measureBtn, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(5) })
        setContentView(root)
        root.requestFocus()
        refreshValues()
    }

    /** Drops focus from the text fields (which commits them) and hides the keyboard. */
    private fun leaveFields() {
        rootView.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(rootView.windowToken, 0)
    }

    private fun commitPoint() {
        if (uiUpdating) return
        val n = pointField.text.toString().toIntOrNull()
        if (n != null && n in 1..MAX_POINT) store.setSetting("next_point", n.toString())
        else toast("Next Point must be 1–$MAX_POINT")
        refreshValues()
    }

    private fun commitCode() {
        if (uiUpdating) return
        val c = codeField.text.toString().trim().uppercase()
        if (c.isEmpty() || c == selectedCode) { refreshValues(); return }
        if (features.isNotEmpty() && !byCode.containsKey(c)) { toast("Code $c not found in FXL"); refreshValues(); return }
        selectCode(c)
    }

    private fun refreshAll() { if (::map.isInitialized) { map.setData(store.allPoints()); refreshValues() } }

    private fun blockNeedOf(code: String) = byCode[code]?.constructionPoints?.takeIf { it > 0 } ?: 1

    private fun refreshValues() {
        uiUpdating = true
        if (!pointField.hasFocus()) pointField.setText(store.nextPointNumber().toString())
        if (!codeField.hasFocus()) codeField.setText(selectedCode)
        uiUpdating = false
        when (kindOf(selectedCode)) {
            "LINE" -> { lineLabel.text = "Line"; lineValue.text = "  $lineNumber  "; lineButtons.forEach { it.visibility = View.VISIBLE } }
            "BLOCK" -> {
                val need = blockNeedOf(selectedCode)
                val slot = store.blockSlot(selectedCode, need)
                lineLabel.text = "Block"; lineValue.text = "  #${slot.first}: point ${slot.second} of $need"
                lineButtons.forEach { it.visibility = View.INVISIBLE }
            }
            else -> { lineLabel.text = ""; lineValue.text = ""; lineButtons.forEach { it.visibility = View.INVISIBLE } }
        }
        for (i in 0 until QUICK_COUNT) {
            quickButtons[i].text = quick[i]
            quickButtons[i].setBackgroundColor(if (quick[i] == selectedCode) selCol else panel)
        }
    }

    // ---------------- GNSS panel ----------------
    private data class Heights(val hEll: Double, val hTip: Double, val hOrtho: Double?)

    /**
     * Height chain, each correction applied exactly once:
     *  GGA altitude is above the receiver geoid (MSL). Ellipsoidal h = altitude + geoid separation (from the same GGA).
     *  Tip height = h (tip mode) or h - pole (antenna mode). Malin Head Z = tip height - N(OSGM15).
     * Returns null when GGA carries no geoid separation (ellipsoidal height cannot be derived).
     */
    private fun heights(fix: GgaFix): Heights? {
        val sep = fix.geoidSeparationM ?: return null
        val hEll = fix.altitudeM + sep
        val hTip = if (tipMode == "antenna") hEll - poleM else hEll
        val n = Osgm15.undulation(fix.latitude, fix.longitude)
        return Heights(hEll, hTip, n?.let { hTip - it })
    }

    private fun f3(v: Double) = String.format(Locale.US, "%.3f", v)

    private fun updateTop() {
        val now = System.currentTimeMillis()
        val s = latest
        val fix = if (s != null && now - s.at <= DISPLAY_STALE_MS) s.v else null
        val g = gstS?.takeIf { fix != null && now - it.at <= DISPLAY_STALE_MS }?.v
        val vd = vdopS?.takeIf { fix != null && now - it.at <= DISPLAY_STALE_MS }?.v
        val acc = Accuracy.resolve(fix, g, vd)
        val grey = Color.LTGRAY
        val (txt, col) = if (fix == null) Pair("--", grey) else when (fix.fixQuality) {
            4 -> Pair("FIX", green)
            5 -> Pair("FLOAT", Color.rgb(240, 190, 60))
            2 -> Pair("DGPS", Color.rgb(235, 150, 70))
            1 -> Pair("SINGLE", Color.rgb(235, 110, 70))
            else -> Pair("NO FIX", Color.rgb(230, 80, 80))
        }
        gnssBar.update(txt, col, fix?.satellites?.toString() ?: "--", acc.h, acc.v, acc.isEstimate, Accuracy.qualityLevel(fix, acc.h))

        if (fix != null) {
            val en = Itm.forward(fix.latitude, fix.longitude)
            val h = heights(fix)
            val z = when { h == null -> "n/a"; h.hOrtho != null -> f3(h.hOrtho); else -> "no grid" }
            coordLine.text = "X ${f3(en.first)}  Y ${f3(en.second)}  Z $z"
        } else coordLine.text = "X --   Y --   Z --"
        connLine.text = "$btState · $ntripState"
        if (::map.isInitialized) map.setCurrent(fix?.latitude, fix?.longitude)
    }

    // ---------------- selection / lines ----------------
    private fun kindOf(c: String) = byCode[c]?.kind ?: "POINT"
    private fun rememberedLine(code: String): Int = store.setting("line_$code", "").toIntOrNull() ?: store.firstFreeLine(code)
    private fun rememberLine() { store.setSetting("line_$selectedCode", lineNumber.toString()) }
    private fun selectCode(code: String) {
        selectedCode = code
        store.setSetting("selected_code", code)
        if (kindOf(code) == "LINE") lineNumber = rememberedLine(code)
        refreshValues()
    }

    private fun loadPole() {
        poleM = store.setting("pole_height_m", "2.000").toDoubleOrNull() ?: 2.0
        tipMode = store.setting("tip_mode", "tip")
    }

    private fun editQuick(i: Int) {
        val et = EditText(this).apply {
            setText(quick[i]); setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(MAX_CODE_LEN))
        }
        AlertDialog.Builder(this).setTitle("Code for cell ${i + 1}").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val c = et.text.toString().trim().uppercase()
                if (c.isEmpty() || (features.isNotEmpty() && !byCode.containsKey(c))) toast("Code $c not found in FXL")
                else { quick[i] = c; store.setSetting("quick_$i", c); refreshValues() }
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------------- measuring ----------------
    private fun measure(force: Boolean) {
        if (pending) return
        pending = true
        connLine.text = "Waiting for GGA…"
        waitFix(System.currentTimeMillis(), force)
    }

    /** Waits for the first GGA epoch after the button press instead of saving an old position. */
    private fun waitFix(press: Long, force: Boolean) {
        val s = latest
        val now = System.currentTimeMillis()
        if (s != null && s.at >= press) { pending = false; proceed(s, force); return }
        if (now - press > 6000) {
            pending = false
            val age = if (s == null) "none" else "${(now - s.at) / 1000} s ago"
            toast("No new GGA within 6 s (last: $age). Check the i76 link and the GGA output rate")
            return
        }
        ui.postDelayed({ waitFix(press, force) }, 80)
    }

    private fun proceed(s: Stamped<GgaFix>, force: Boolean) {
        val fix = s.v
        val age = System.currentTimeMillis() - s.at
        if (age > MAX_FIX_AGE_MS) { toast("GNSS position is stale ($age ms). Point not saved"); return }
        val next = store.nextPointNumber()
        if (next !in 1..MAX_POINT) { toast("Next Point must be 1–$MAX_POINT"); return }
        if (!force && fix.fixQuality != 4) { toast("No RTK FIX (current fix: ${fix.fixQuality}). Long press MEASURE to save anyway"); return }
        if (fix.geoidSeparationM == null) { toast("GGA has no geoid separation: ellipsoidal height cannot be derived. Point not saved"); return }
        val g = gstS?.takeIf { abs(it.at - s.at) <= 2500 }?.v
        val vd = vdopS?.takeIf { abs(it.at - s.at) <= 2500 }?.v
        val acc = Accuracy.resolve(fix, g, vd)
        val f = byCode[selectedCode]
        if (f != null && f.attributes.isNotEmpty()) attrDialog(f, emptyMap()) { save(fix, acc, it) } else save(fix, acc, JSONObject())
    }

    private fun save(fix: GgaFix, acc: AccuracyInfo, attrs: JSONObject) {
        try {
            val h = heights(fix) ?: run { toast("GGA has no geoid separation. Point not saved"); return }
            val n = store.nextPointNumber()
            if (store.pointExists(n)) { toast("Point $n already exists. Change Next Point"); return }
            val kind = kindOf(selectedCode)
            var lineVal = 0
            var closed = false
            if (kind == "LINE") lineVal = lineNumber
            else if (kind == "BLOCK") {
                val need = blockNeedOf(selectedCode)
                val slot = store.blockSlot(selectedCode, need)
                lineVal = slot.first; closed = slot.second >= need
            }
            store.savePoint(n, fix, h.hEll, h.hTip, tipMode, selectedCode, lineVal, poleM, attrs.toString(), h.hOrtho, acc.h, acc.v, acc.source.name)
            if (kind == "LINE") rememberLine()
            val extra = if (h.hOrtho == null) "\nOSGM15 grid unavailable: Malin Head height not stored" else ""
            toast((if (closed) "Point $n saved. Block closed" else "Point $n saved") + extra)
            refreshAll()
        } catch (e: Exception) { toast("Save error: ${e.message}") }
    }

    /** Dynamic attribute form built from the FXL. Values are NOT carried over from earlier points. */
    private fun attrDialog(f: FeatureCode, existing: Map<String, String>, onOk: (JSONObject) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val getters = ArrayList<Pair<String, () -> String>>()
        for (a in f.attributes) {
            val title = a.name + (a.description?.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: "") + "  [${a.type}]"
            box.addView(TextView(this).apply { text = title; textSize = 12f; setPadding(0, dp(8), 0, 0) })
            val init = existing[a.name] ?: a.defaultValue ?: ""
            if (a.type == "Boolean") {
                val cb = CheckBox(this).apply { isChecked = init.equals("true", true) }
                box.addView(cb); getters += (a.name to { if (cb.isChecked) "true" else "false" })
            } else {
                val numeric = a.type == "Double" || a.type == "Integer"
                val et = EditText(this).apply {
                    setText(init); setSingleLine()
                    inputType = if (numeric) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED else InputType.TYPE_CLASS_TEXT
                }
                box.addView(et); getters += (a.name to { if (numeric) et.text.toString().trim().replace(',', '.') else et.text.toString().trim() })
            }
        }
        AlertDialog.Builder(this).setTitle("${f.code} · ${f.name}").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK") { _, _ -> val j = JSONObject(); for ((n, g) in getters) j.put(n, g()); onOk(j) }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- points ----------------
    private fun showPoint(p: Pt) {
        val en = Itm.forward(p.lat, p.lon)
        val kindTxt = when (kindOf(p.code)) { "LINE" -> "   Line: ${p.line}"; "BLOCK" -> "   Block #${p.line}"; else -> "" }
        val acc = if (p.accSrc.isEmpty()) "n/a" else "H ${p.hAcc?.let { f3(it) } ?: "--"} m / V ${p.vAcc?.let { f3(it) } ?: "--"} m (${if (p.accSrc == "RECEIVER_GST") "receiver GST" else "estimate from DOP"})"
        val msg = "Point ${p.number}\nCode: ${p.code}$kindTxt\n\n" +
            "X (ITM E): ${f3(en.first)}\nY (ITM N): ${f3(en.second)}\n" +
            "Z (Malin Head, OSGM15): ${p.hOrtho?.let { f3(it) } ?: "not stored"}\n\n" +
            "Lat: ${String.format(Locale.US, "%.9f", p.lat)}\nLon: ${String.format(Locale.US, "%.9f", p.lon)}\n" +
            "h ellipsoidal (GGA alt + geoid sep): ${f3(p.hEll)}\nh tip (recorded): ${f3(p.hTip)}\n" +
            "Mode: ${if (p.tipMode == "antenna") "antenna, pole ${f3(p.pole)} subtracted" else "tip, no correction"}\n" +
            "Fix ${p.fixQ} · ${p.sats} sv · HDOP ${p.hdop ?: "-"}\nAccuracy: $acc\nUTC ${p.utc}\n\nAttributes: ${p.attrs}"
        AlertDialog.Builder(this).setTitle("Point ${p.number}").setMessage(msg)
            .setPositiveButton("Close", null)
            .setNeutralButton("Edit") { _, _ -> editPoint(p) }
            .setNegativeButton("Delete") { _, _ ->
                AlertDialog.Builder(this).setMessage("Delete point ${p.number}?")
                    .setPositiveButton("Delete") { _, _ -> store.deletePoint(p.id); refreshAll() }
                    .setNegativeButton("Cancel", null).show()
            }.show()
    }

    private fun editPoint(p: Pt) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val code = EditText(this).apply {
            setText(p.code); setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(MAX_CODE_LEN))
        }
        val line = EditText(this).apply { setText(p.line.toString()); inputType = InputType.TYPE_CLASS_NUMBER }
        box.addView(TextView(this).apply { text = "Code" }); box.addView(code)
        box.addView(TextView(this).apply { text = "Line number (line codes only)" }); box.addView(line)
        AlertDialog.Builder(this).setTitle("Edit point ${p.number}").setView(box)
            .setPositiveButton("Next") { _, _ ->
                val c = code.text.toString().trim().uppercase()
                val k = kindOf(c)
                val l0 = line.text.toString().toIntOrNull()
                if (c.isEmpty() || (features.isNotEmpty() && !byCode.containsKey(c)) || (k == "LINE" && (l0 == null || l0 < 1))) { toast("Invalid code or line"); return@setPositiveButton }
                val l = when (k) { "LINE" -> l0!!; "BLOCK" -> maxOf(p.line, 1); else -> 0 }
                val old = try { JSONObject(p.attrs) } catch (e: Exception) { JSONObject() }
                val f = byCode[c]
                if (f != null && f.attributes.isNotEmpty()) {
                    val ex = HashMap<String, String>(); for (key in old.keys()) ex[key] = old.optString(key)
                    attrDialog(f, ex) { store.updatePoint(p.id, c, l, it.toString()); refreshAll() }
                } else { store.updatePoint(p.id, c, l, "{}"); refreshAll() }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showPointList() {
        val list = store.allPoints().reversed().take(300)
        if (list.isEmpty()) { toast("No points yet"); return }
        AlertDialog.Builder(this).setTitle("Points (newest first)")
            .setItems(list.map { "#${it.number}   ${it.code}${when (kindOf(it.code)) { "LINE" -> " " + it.line; "BLOCK" -> " block " + it.line; else -> "" }}" }.toTypedArray()) { _, i -> showPoint(list[i]) }
            .setNegativeButton("Close", null).show()
    }

    // ---------------- menu / settings ----------------
    private fun showMenu() {
        leaveFields()
        val items = arrayOf("Connect receiver (Bluetooth)", "Raw NMEA / diagnostics", "Point list", "Pole height & mode", "Export JXL + CSV (to Downloads)", "NTRIP: corrections over internet")
        AlertDialog.Builder(this).setTitle("Menu").setItems(items) { _, i ->
            when (i) { 0 -> connectMenu(); 1 -> showDiag(); 2 -> showPointList(); 3 -> showPoleSettings(); 4 -> doExport(); 5 -> ntripDialog() }
        }.show()
    }

    private fun showPoleSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(store.setting("pole_height_m", "2.000")) }
        val rg = RadioGroup(this)
        val r1 = RadioButton(this).apply { id = 1; text = "i76 reports the POLE TIP: do not subtract pole height" }
        val r2 = RadioButton(this).apply { id = 2; text = "i76 reports the ANTENNA: subtract pole height (pole must be plumb)" }
        rg.addView(r1); rg.addView(r2)
        rg.check(if (tipMode == "antenna") 2 else 1)
        box.addView(TextView(this).apply { text = "Pole height, m" }); box.addView(et); box.addView(rg)
        AlertDialog.Builder(this).setTitle("Pole").setView(box)
            .setPositiveButton("OK") { _, _ ->
                val h = et.text.toString().replace(',', '.').toDoubleOrNull()
                if (h == null || h < 0 || h > 5) { toast("Invalid height"); return@setPositiveButton }
                store.setSetting("pole_height_m", String.format(Locale.US, "%.3f", h))
                store.setSetting("tip_mode", if (rg.checkedRadioButtonId == 2) "antenna" else "tip")
                loadPole()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun doExport() {
        val pts = store.allPoints()
        if (pts.isEmpty()) { toast("No points to export"); return }
        try {
            val names = Exporter.export(this, pts) { byCode[it]?.kind ?: "POINT" }
            AlertDialog.Builder(this).setTitle("Saved to Downloads").setMessage(names).setPositiveButton("OK", null).show()
        } catch (e: Exception) { toast("Export error: ${e.message}") }
    }

    // ---------------- bluetooth / diagnostics ----------------
    private fun hasBt() = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun connectMenu() {
        if (!hasBt()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 7); return }
        pickDevice()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) pickDevice()
        else if (requestCode == 7) toast("Bluetooth permission is required to connect")
    }

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { toast("Turn Bluetooth on"); return }
        val devs = ad.bondedDevices.toList()
        if (devs.isEmpty()) { toast("Pair the i76 in Android Bluetooth settings first"); return }
        AlertDialog.Builder(this).setTitle("Select receiver")
            .setItems(devs.map { "${it.name} (${it.address})" }.toTypedArray()) { _, i -> store.setSetting("bt_addr", devs[i].address); gnss.start(devs[i]) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun autoConnect() {
        val addr = store.setting("bt_addr", "")
        if (addr.isEmpty() || !hasBt()) return
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
        if (!ad.isEnabled) return
        ad.bondedDevices.firstOrNull { it.address == addr }?.let { gnss.start(it) }
    }

    private fun onLine(line: String) {
        synchronized(rawLog) { rawLog.addLast(line); while (rawLog.size > 40) rawLog.removeFirst() }
        val type = if (line.startsWith("$") && line.length >= 6) line.substring(1, 6) else line.take(8)
        synchronized(counts) { counts[type] = (counts[type] ?: 0) + 1 }
        val now = System.currentTimeMillis()
        val kind = if (line.startsWith("$") && line.length >= 6) line.substring(3, 6) else ""
        when (kind) {
            "GGA" -> NmeaParser.parseGga(line)?.let { ggaInterval = now - (latest?.at ?: now); latest = Stamped(it, now); lastGga = line }
            "GST" -> NmeaParser.parseGst(line)?.let { gstS = Stamped(it, now) }
            "GSA" -> NmeaParser.parseGsa(line)?.vdop?.let { vdopS = Stamped(it, now) }
        }
    }

    private fun showDiag() {
        val tv = TextView(this).apply { textSize = 10f; typeface = Typeface.MONOSPACE; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        diagText = tv
        diagDialog = AlertDialog.Builder(this).setTitle("Receiver stream").setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Close", null).show()
        updateDiag()
    }

    private fun updateDiag() {
        val d = diagDialog ?: return
        val tv = diagText ?: return
        if (!d.isShowing) return
        val now = System.currentTimeMillis()
        val fix = latest?.takeIf { now - it.at <= DISPLAY_STALE_MS }?.v
        val acc = Accuracy.resolve(fix, gstS?.takeIf { now - it.at <= DISPLAY_STALE_MS }?.v, vdopS?.takeIf { now - it.at <= DISPLAY_STALE_MS }?.v)
        val c = synchronized(counts) { counts.entries.sortedBy { it.key }.joinToString("\n") { "${it.key}: ${it.value}" } }
        val l = synchronized(rawLog) { rawLog.toList().takeLast(25).joinToString("\n") }
        tv.text = "GGA interval: $ggaInterval ms\nAccuracy source: ${acc.source}\n${Osgm15.status}\n\nMessage types:\n$c\n\nLatest lines:\n$l"
    }

    // ---------------- NTRIP ----------------
    private fun startNtrip() {
        val h = store.setting("ntrip_host", "")
        if (h.isEmpty()) return
        ntrip.start(h, store.setting("ntrip_port", "2101").toIntOrNull() ?: 2101,
            store.setting("ntrip_mount", ""), store.setting("ntrip_user", ""), store.setting("ntrip_pass", ""))
    }

    private fun ntripDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        fun field(title: String, key: String, def: String, pass: Boolean = false, num: Boolean = false): EditText {
            box.addView(TextView(this).apply { text = title; textSize = 12f; setPadding(0, dp(6), 0, 0) })
            val et = EditText(this).apply {
                setText(store.setting(key, def)); setSingleLine()
                inputType = if (num) InputType.TYPE_CLASS_NUMBER
                    else if (pass) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            }
            box.addView(et); return et
        }
        box.addView(TextView(this).apply { text = "For all constellations (GPS+GLONASS+Galileo+BeiDou) choose an RTCM 3.x MSM mountpoint. Use the button below to list them."; textSize = 11f })
        val host = field("Caster address (host)", "ntrip_host", "")
        val port = field("Port", "ntrip_port", "2101", num = true)
        val mount = field("Mountpoint", "ntrip_mount", "")
        val user = field("Username", "ntrip_user", "")
        val pass = field("Password", "ntrip_pass", "", pass = true)
        box.addView(Button(this).apply {
            text = "List mountpoints from caster"; isAllCaps = false
            setOnClickListener {
                val h = host.text.toString().trim(); val pt = port.text.toString().trim().toIntOrNull() ?: 2101
                val u = user.text.toString().trim(); val pw = pass.text.toString()
                toast("Requesting list…")
                Thread {
                    try {
                        val rows = NtripClient.sourcetable(h, pt, u, pw)
                        runOnUiThread {
                            if (rows.isEmpty()) toast("Caster returned no list")
                            else AlertDialog.Builder(this@MainActivity).setTitle("Mountpoints (RTCM 3 MSM needed)")
                                .setItems(rows.map { r -> "${r.getOrElse(1) { "?" }} · ${r.getOrElse(3) { "" }} ${r.getOrElse(4) { "" }} · ${r.getOrElse(6) { "" }}" }.toTypedArray()) { _, i -> mount.setText(rows[i].getOrElse(1) { "" }) }
                                .show()
                        }
                    } catch (e: Exception) { runOnUiThread { toast("Could not get the list: ${e.javaClass.simpleName}") } }
                }.start()
            }
        })
        AlertDialog.Builder(this).setTitle("NTRIP (phone needs internet)").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save and connect") { _, _ ->
                store.setSetting("ntrip_host", host.text.toString().trim())
                store.setSetting("ntrip_port", port.text.toString().trim())
                store.setSetting("ntrip_mount", mount.text.toString().trim().removePrefix("/"))
                store.setSetting("ntrip_user", user.text.toString().trim())
                store.setSetting("ntrip_pass", pass.text.toString())
                startNtrip()
            }
            .setNeutralButton("Turn off") { _, _ -> store.setSetting("ntrip_host", ""); ntrip.stop() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- helpers ----------------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun cardColumn() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(9), dp(4), dp(9), dp(4)); setBackgroundColor(panel) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun smallButton(s: String, action: () -> Unit) = Button(this).apply { text = s; textSize = 11f; isAllCaps = false; minWidth = dp(42); setPadding(dp(6), 0, dp(6), 0); setOnClickListener { action() } }
    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
