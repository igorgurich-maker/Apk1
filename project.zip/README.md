# Gurich Survey 0.9.10 (not build-verified, not field-tested)

UI language: English only (forced in code, independent of phone language).

Top GNSS panel: RTK Status, Satellites, H/V Accuracy, Positioning Quality. Missing data shows "--".
Accuracy: receiver GST (sigma lat/lon/alt) when present; otherwise DOP x UERE estimate, shown with "~".
Heights: ellipsoidal h = GGA altitude + GGA geoid separation (once); Z = h - N(OSGM15).
OSGM15 grid (OSGM15_Malin.GGF, TNL format) is bundled in app/src/main/assets/. Check Menu > Raw NMEA / diagnostics: it shows N and the difference to the receiver geoid separation.
Map: Point / Line / Block (rectangle or circle), single colour, no labels.
Quick Codes: 4 x 3 grid. Next Point max 4 digits, Current Code max 5 characters.

## Change log
0.9.10: Top bar: RTK Status, Satellites, 3D Accuracy, Next Point (editable, was V Accuracy). 3D = sqrt(H² + V²); "~" = estimate. When the receiver sends no
        vertical value (GGA only) V is assumed 1.5 x H, shown with "~". The quality bar has no text label any more. X Y Z and the link status (BT / NTRIP) share
        one thin line; the project name is in the title row.
0.9.9: Map follows you: the current position stays at the screen centre at the current scale (scale no longer changes while walking).
       Drag with one or two fingers (or pinch) to look elsewhere; after 10 s without touching the map it centres on you again. Double tap = fit and follow.
       The black line strip is gone: the map reaches down to the quick-code page bars. -, + and Search (line codes), block progress and attribute fields
       float over the bottom of the map. Menu > Send command to receiver: sends one text line (+ CR LF) to the receiver, e.g. to raise its output rate
       (syntax is receiver-specific, not verified for the i76). Sent commands are written to the receiver log as "# TX ...".
0.9.8: Next Point moved to the right end of the X Y Z line; delete-last (trash) floats over the top-right corner of the map.
       -, + and Search are large and share the whole strip width. Quick codes: title and "1/2" removed, three short bars above the grid show the page (current one is green; tap = next page).
       Third page of quick codes (36 cells). A NEW project starts with all quick cells empty ("+"): tap an empty cell to type a code; empty input clears a cell.
       Projects made earlier keep their old default codes.
0.9.7: Every quick cell is its own theme: two cells with the same code (RE + RE) keep separate line numbers (RE2 / RE3) and are highlighted separately.
       Line memory is saved per cell; changing a cell's code resets that cell's line to the last used line of the new code.
       Line strip: -, +, Search, trash and Next Point all have the same height. Next Point digits are right-aligned (away from the trash).
0.9.6: NTRIP settings are kept in the app, not in a project. The last successful connection is reused at every start (auto connect).
       If the caster refuses the login (401/403, "in use", "Bad Password"), a window asks for another login and password.
       Menu > NTRIP > Turn off stops auto connect until you connect again.
0.9.5: Map: pinch zoom, two-finger pan, double tap on empty map = zoom reset and centre on the current position.
       Point labels "number code" on the map, switch in menu (Point labels: ON/OFF).
       Blocks: 1 point = point only; 2 points = straight line between them (no circle); 3+ points = rectangle.
0.9.4: Line codes: the quick button always shows its line number (RE1, RE2 ...) until it is changed. Line strip below the map: [- + Search] on the left (line codes only),
       block progress as "n of N" (closed: "N of N - closed"), then delete-last (green icon) and Next Point on the right. Code field removed from the screen.
       Map background back to the original colour.
0.9.3: Projects: menu > New project / Open project (simple names; each project keeps its own points, quick codes and settings). Top line shows the project name.
       Menu > Save receiver log to Downloads: every raw NMEA line of a Bluetooth connection is recorded (file nmea_YYYYMMDD_HHMMSS.txt).
       Menu > Exit: stops receiver and NTRIP and closes the app. Map background is brand green. New app icon (white G on green).
0.9.2: Top bar and map hold the last good values; no blink to "--" between GGA epochs (cleared only after 15 s without GGA).
       V Accuracy no longer shows a dash when GST has no altitude sigma: falls back to VDOP x UERE, shown with "~".
       Line codes show their line on the quick button (RE1, RE2 ...); Search, + and - update the button label.
0.9.1: Quick Codes page number (1/2, 2/2) is a large button on the right of the title row. Messages are in-app pills in the MEASURE style
       (green, dark red for problems) instead of Android toasts. Delete asks for confirmation (pill with Delete / Cancel). Deleting the last point
       of a closed block reopens that block.
0.9.0: Block codes: full-width status text on the strip (stage, points left, "closed" note), no -/+/Search, double beep when a block closes.
       Attributes are now entered AFTER the point is saved: the strip switches to attribute fields (scrolls if more than 2) and MEASURE is locked
       until the check button confirms them. Pending state survives app restarts; deleting that point unlocks MEASURE.
0.8.0: Delete-last button (trash, left of Next Point): removes the newest point and returns its number. Beep on every saved point.
0.7.3: App renamed Gurich Survey (package id unchanged, so it installs over the old one). Map: line/block colours from the FXL (layer colours), small uniform dot on every point.
0.7.2: MEASURE uses the latest GGA immediately when it is <= 1 s old (points every second); wait for next GGA limited to 4 s; toasts no longer queue.
0.7.1: OSGM15 grid bundled (GGF reader). Diagnostics show N, GGA separation and their difference.
0.7.0: Line strip is always visible. Line codes: Line number with -/+/Search. Block codes: block progress. Other codes: "Line --", buttons inert.
       Non-line codes with 1-2 attributes (e.g. TR: TRUNK, SPREAD): inline fields on the strip + check button; values are cleared after each save.
       Features with more than 2 attributes, and line features with attributes, still use the attribute dialog.
0.6.0: Next Point / Code fields floating over bottom-right of the map; map extends down to the Line row.
       Quick Codes: 2 pages x 12 (swipe left/right or tap the title). Page-2 defaults: KT WD BG HE PA TB BB IL FL BU BO RS.
       Returning to a line code continues the last used line (saved per code); + starts a new line.
0.5.0: English-only UI, GNSS top bar, GST accuracy, OSGM15 Z (grid file needed), 4x3 quick codes, map Point/Line/Block.
TODO: verify OSGM15 Z against a known TBC point; verify GST output on i76; field test.
