# Gurich Survey 0.9.5 (not build-verified, not field-tested)

UI language: English only (forced in code, independent of phone language).

Top GNSS panel: RTK Status, Satellites, H/V Accuracy, Positioning Quality. Missing data shows "--".
Accuracy: receiver GST (sigma lat/lon/alt) when present; otherwise DOP x UERE estimate, shown with "~".
Heights: ellipsoidal h = GGA altitude + GGA geoid separation (once); Z = h - N(OSGM15).
OSGM15 grid (OSGM15_Malin.GGF, TNL format) is bundled in app/src/main/assets/. Check Menu > Raw NMEA / diagnostics: it shows N and the difference to the receiver geoid separation.
Map: Point / Line / Block (rectangle or circle), single colour, no labels.
Quick Codes: 4 x 3 grid. Next Point max 4 digits, Current Code max 5 characters.

## Change log
0.9.5: Map: pinch zoom, two-finger pan, double tap on empty map = zoom reset and centre on the current position.
       Point labels "number code" on the map, switch in menu (Point labels: ON/OFF).
       Blocks: 1 point = point only; 2 points = straight line between them (no circle); 3+ points = rectangle.
0.9.4: Line codes: the quick button always shows its line number (RE1, RE2 ...) until it is changed. Line strip below the map: [- + Search] on the left (line codes only),
       block progress as "n of N" (closed: "N of N - closed"), then delete-last (green icon) and Next Point on the right. Code field removed from the screen.
       Map background back to the original colour.
0.9.3: Projects: menu > New project / Open project (simple names; each project keeps its own points, quick codes and settings). Top line shows the project name.
       Menu > Save receiver log to Downloads: every raw NMEA line of a Bluetooth connection is recorded (file nmea_YYYYMMDD_HHMMSS.txt).
       Menu > Exit: stops receiver and NTRIP and closes the app. Map background is brand green. New app icon (white G on green).
0.9.2: Top bar and map hold the last good values; no blink to "--" between GGA epochs (cleared only after 15 s without GGA).
       V Accuracy no longer shows a dash when GST has no altitude sigma: falls back to VDOP x UERE, shown with "~".
       Line codes show their line on the quick button (RE1, RE2 ...); Search, + and - update the button label.
0.9.1: Quick Codes page number (1/2, 2/2) is a large button on the right of the title row. Messages are in-app pills in the MEASURE style
       (green, dark red for problems) instead of Android toasts. Delete asks for confirmation (pill with Delete / Cancel). Deleting the last point
       of a closed block reopens that block.
0.9.0: Block codes: full-width status text on the strip (stage, points left, "closed" note), no -/+/Search, double beep when a block closes.
       Attributes are now entered AFTER the point is saved: the strip switches to attribute fields (scrolls if more than 2) and MEASURE is locked
       until the check button confirms them. Pending state survives app restarts; deleting that point unlocks MEASURE.
0.8.0: Delete-last button (trash, left of Next Point): removes the newest point and returns its number. Beep on every saved point.
0.7.3: App renamed Gurich Survey (package id unchanged, so it installs over the old one). Map: line/block colours from the FXL (layer colours), small uniform dot on every point.
0.7.2: MEASURE uses the latest GGA immediately when it is <= 1 s old (points every second); wait for next GGA limited to 4 s; toasts no longer queue.
0.7.1: OSGM15 grid bundled (GGF reader). Diagnostics show N, GGA separation and their difference.
0.7.0: Line strip is always visible. Line codes: Line number with -/+/Search. Block codes: block progress. Other codes: "Line --", buttons inert.
       Non-line codes with 1-2 attributes (e.g. TR: TRUNK, SPREAD): inline fields on the strip + check button; values are cleared after each save.
       Features with more than 2 attributes, and line features with attributes, still use the attribute dialog.
0.6.0: Next Point / Code fields floating over bottom-right of the map; map extends down to the Line row.
       Quick Codes: 2 pages x 12 (swipe left/right or tap the title). Page-2 defaults: KT WD BG HE PA TB BB IL FL BU BO RS.
       Returning to a line code continues the last used line (saved per code); + starts a new line.
0.5.0: English-only UI, GNSS top bar, GST accuracy, OSGM15 Z (grid file needed), 4x3 quick codes, map Point/Line/Block.
TODO: verify OSGM15 Z against a known TBC point; verify GST output on i76; field test.
