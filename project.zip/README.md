# Topo Survey 0.5.0 (not build-verified, not field-tested)

UI language: English only (forced in code, independent of phone language).

Top GNSS panel: RTK Status, Satellites, H/V Accuracy, Positioning Quality. Missing data shows "--".
Accuracy: receiver GST (sigma lat/lon/alt) when present; otherwise DOP x UERE estimate, shown with "~".
Heights: ellipsoidal h = GGA altitude + GGA geoid separation (once); Z = h - N(OSGM15).
OSGM15 grid is NOT bundled: put osgm15_malin.gtx in app/src/main/assets/ or in the app external files dir.
Map: Point / Line / Block (rectangle or circle), single colour, no labels.
Quick Codes: 4 x 3 grid. Next Point max 4 digits, Current Code max 5 characters.

## Change log
0.7.0: Line strip is always visible. Line codes: Line number with -/+/Search. Block codes: block progress. Other codes: "Line --", buttons inert.
       Non-line codes with 1-2 attributes (e.g. TR: TRUNK, SPREAD): inline fields on the strip + check button; values are cleared after each save.
       Features with more than 2 attributes, and line features with attributes, still use the attribute dialog.
0.6.0: Next Point / Code fields floating over bottom-right of the map; map extends down to the Line row.
       Quick Codes: 2 pages x 12 (swipe left/right or tap the title). Page-2 defaults: KT WD BG HE PA TB BB IL FL BU BO RS.
       Returning to a line code continues the last used line (saved per code); + starts a new line.
0.5.0: English-only UI, GNSS top bar, GST accuracy, OSGM15 Z (grid file needed), 4x3 quick codes, map Point/Line/Block.
TODO: osgm15_malin.gtx grid; verify GST output on i76; field test.
