# Topo Survey 0.5.0 (not build-verified, not field-tested)

UI language: English only (forced in code, independent of phone language).

Top GNSS panel: RTK Status, Satellites, H/V Accuracy, Positioning Quality. Missing data shows "--".
Accuracy: receiver GST (sigma lat/lon/alt) when present; otherwise DOP x UERE estimate, shown with "~".
Heights: ellipsoidal h = GGA altitude + GGA geoid separation (once); Z = h - N(OSGM15).
OSGM15 grid is NOT bundled: put osgm15_malin.gtx in app/src/main/assets/ or in the app external files dir.
Map: Point / Line / Block (rectangle or circle), single colour, no labels.
Quick Codes: 4 x 3 grid. Next Point max 4 digits, Current Code max 5 characters.
