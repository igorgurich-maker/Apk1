package com.igor.toposurvey

import android.content.Context
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

/** Container that reports horizontal swipes (-1 = swipe right / previous, +1 = swipe left / next) while letting taps reach child buttons. */
class SwipeLayout(ctx: Context, private val onSwipe: (Int) -> Unit) : FrameLayout(ctx) {
    private var x0 = 0f
    private var y0 = 0f
    private var swiping = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.x; y0 = e.y; swiping = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - x0; val dy = e.y - y0
                if (abs(dx) > slop * 3 && abs(dx) > abs(dy) * 1.5f) swiping = true
            }
        }
        return swiping
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_UP -> {
                if (swiping) { val dx = e.x - x0; if (abs(dx) > slop * 6) onSwipe(if (dx < 0) 1 else -1) }
                swiping = false
            }
            MotionEvent.ACTION_CANCEL -> swiping = false
        }
        return true
    }
}
