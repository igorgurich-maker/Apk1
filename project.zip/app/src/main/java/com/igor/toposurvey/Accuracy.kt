package com.igor.toposurvey

import kotlin.math.sqrt

/** Horizontal / vertical accuracy (metres, 1-sigma) and where the numbers came from. */
data class AccuracyInfo(val h: Double?, val v: Double?, val source: Source) {
    enum class Source { RECEIVER_GST, ESTIMATE_DOP, NONE }
    val isEstimate: Boolean get() = source == Source.ESTIMATE_DOP
}

object Accuracy {
    /**
     * Metres of 1-sigma error per unit of DOP, by GGA fix quality. These are ESTIMATES used only when the
     * receiver does not send GST. Tune them against your receiver's own GST output in the field.
     */
    fun uere(fixQuality: Int): Double = when (fixQuality) {
        4 -> 0.02   // RTK fixed
        5 -> 0.20   // RTK float
        2 -> 0.80   // DGPS
        1 -> 3.00   // autonomous
        else -> 5.00
    }

    /**
     * Priority: 1) receiver GST (sigma lat/lon/alt), 2) DOP x UERE.
     * Pass null for gst / vdop when they are missing or stale; the caller decides what "stale" means.
     */
    fun resolve(fix: GgaFix?, gst: GstData?, vdop: Double?): AccuracyInfo {
        if (fix == null) return AccuracyInfo(null, null, AccuracyInfo.Source.NONE)
        if (gst != null) {
            val h = sqrt(gst.sigmaLat * gst.sigmaLat + gst.sigmaLon * gst.sigmaLon)
            return AccuracyInfo(h, gst.sigmaAlt, AccuracyInfo.Source.RECEIVER_GST)
        }
        val k = uere(fix.fixQuality)
        val h = fix.hdop?.let { it * k }
        val v = vdop?.let { it * k }
        return if (h == null && v == null) AccuracyInfo(null, null, AccuracyInfo.Source.NONE)
        else AccuracyInfo(h, v, AccuracyInfo.Source.ESTIMATE_DOP)
    }

    /** 0 = no fix ... 4 = best. Used by the quality indicator. */
    fun qualityLevel(fix: GgaFix?, hAcc: Double?): Int {
        if (fix == null || !fix.hasFix) return 0
        return when (fix.fixQuality) {
            4 -> if (hAcc != null && hAcc <= 0.03) 4 else 3
            5 -> 2
            else -> 1
        }
    }

    fun qualityLabel(level: Int): String = when (level) {
        4 -> "EXCELLENT"; 3 -> "GOOD"; 2 -> "FAIR"; 1 -> "POOR"; else -> "NO FIX"
    }
}
