package com.igor.toposurvey

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Exports to Downloads: JobXML (.jxl, experimental - must be validated in TBC) and CSV. */
object Exporter {
    fun export(ctx: Context, pts: List<Pt>, kindOf: (String) -> String): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val a = "TopoSurvey_$stamp.jxl"
        val b = "TopoSurvey_$stamp.csv"
        save(ctx, a, jxl(pts, kindOf))
        save(ctx, b, csv(pts))
        return "$a\n$b"
    }

    private fun save(ctx: Context, name: String, text: String) {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw IllegalStateException("MediaStore insert failed")
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
    }

    private fun f(v: Double, n: Int) = String.format(Locale.US, "%.${n}f", v)
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun csv(pts: List<Pt>): String {
        val sb = StringBuilder("Point,Code,Line,East_ITM,North_ITM,Lat,Lon,H_ellipsoid,H_tip,PoleHeight,TipMode,Fix,Sats,HDOP,SavedUTC,Attributes,H_Malin_OSGM15,H_Acc,V_Acc,Acc_Source\n")
        for (p in pts) {
            val en = Itm.forward(p.lat, p.lon)
            sb.append("${p.number},${p.code},${p.line},${f(en.first, 3)},${f(en.second, 3)},${f(p.lat, 10)},${f(p.lon, 10)},")
            sb.append("${f(p.hEll, 3)},${f(p.hTip, 3)},${f(p.pole, 3)},${p.tipMode},${p.fixQ},${p.sats},${p.hdop ?: ""},${p.savedAt},\"${p.attrs.replace("\"", "\"\"")}\",")
            sb.append("${p.hOrtho?.let { f(it, 3) } ?: ""},${p.hAcc?.let { f(it, 3) } ?: ""},${p.vAcc?.let { f(it, 3) } ?: ""},${p.accSrc}\n")
        }
        return sb.toString()
    }

    fun jxl(pts: List<Pt>, kindOf: (String) -> String): String {
        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<JOBFile jobName=\"TopoSurvey\" version=\"6.20\" product=\"TopoSurvey\" productVersion=\"0.5.0\" timeStamp=\"$now\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n<FieldBook>\n")
        sb.append("<ProjectionRecord ID=\"00000001\" TimeStamp=\"$now\"><Projection><Type>TransverseMercator</Type><ShiftGridFileName/><CentralLatitude>53.5</CentralLatitude><CentralLongitude>-8</CentralLongitude><FalseNorthing>750000</FalseNorthing><FalseEasting>600000</FalseEasting><Scale>0.99982</Scale></Projection></ProjectionRecord>\n")
        sb.append("<DatumRecord ID=\"00000002\" TimeStamp=\"$now\"><Type>ThreeParameter</Type><Direction>WGS84ToLocal</Direction><EarthRadius>6378137</EarthRadius><Flattening>0.00335281067183</Flattening><TranslationX>0</TranslationX><TranslationY>0</TranslationY><TranslationZ>0</TranslationZ><ReferenceGlobalFrameID>201</ReferenceGlobalFrameID></DatumRecord>\n")
        sb.append("<CoordinateSystemRecord ID=\"00000003\" TimeStamp=\"$now\"><SystemName>Ireland/Republic of Ireland</SystemName><ZoneName>IRENET95 Irish Trans. Mercator</ZoneName><DatumName>Ordnance Survey</DatumName></CoordinateSystemRecord>\n")
        var id = 16
        for (p in pts) {
            val code = if (kindOf(p.code) != "LINE") p.code else "${p.code}${p.line}"
            sb.append("<PointRecord ID=\"%08x\" TimeStamp=\"${p.savedAt}\">\n".format(id++))
            sb.append("<Name>${p.number}</Name><Code>${esc(code)}</Code><Method>DirectReading</Method><SurveyMethod>Fix</SurveyMethod><Classification>Normal</Classification><Deleted>false</Deleted>\n")
            val j = try { JSONObject(p.attrs) } catch (e: Exception) { JSONObject() }
            if (j.length() > 0) {
                sb.append("<Features><Feature Name=\"${esc(p.code)}\">\n")
                for (k in j.keys()) sb.append("<Attribute><Name>${esc(k)}</Name><Value>${esc(j.optString(k))}</Value><Type>Text</Type></Attribute>\n")
                sb.append("</Feature></Features>\n")
            }
            sb.append("<WGS84><Latitude>${f(p.lat, 12)}</Latitude><Longitude>${f(p.lon, 12)}</Longitude><Height>${f(p.hTip, 4)}</Height></WGS84>\n</PointRecord>\n")
        }
        sb.append("</FieldBook>\n</JOBFile>\n")
        return sb.toString()
    }
}
