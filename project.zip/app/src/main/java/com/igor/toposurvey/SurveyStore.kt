package com.igor.toposurvey

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Pt(
    val id: Long, val number: Int, val lat: Double, val lon: Double,
    val hEll: Double, val hTip: Double, val tipMode: String,
    val code: String, val line: Int, val pole: Double,
    val fixQ: Int, val sats: Int, val hdop: Double?, val utc: String, val savedAt: String, val attrs: String,
    val hOrtho: Double? = null, val hAcc: Double? = null, val vAcc: Double? = null, val accSrc: String = ""
)

class SurveyStore(context: Context, name: String) : SQLiteOpenHelper(context, "$name.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            point_number INTEGER NOT NULL UNIQUE,
            latitude REAL NOT NULL, longitude REAL NOT NULL,
            h_ell REAL NOT NULL, h_tip REAL NOT NULL, tip_mode TEXT NOT NULL,
            code TEXT NOT NULL, line_number INTEGER NOT NULL,
            pole_height_m REAL NOT NULL,
            fix_quality INTEGER NOT NULL, satellites INTEGER NOT NULL, hdop REAL,
            utc TEXT NOT NULL, saved_at TEXT NOT NULL,
            attributes_json TEXT NOT NULL DEFAULT '{}',
            h_ortho REAL, h_acc REAL, v_acc REAL, acc_src TEXT NOT NULL DEFAULT ''
        )""")
        db.execSQL("CREATE INDEX idx_points_feature ON points(code, line_number)")
        db.execSQL("CREATE TABLE project_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execSQL("INSERT INTO project_settings(key,value) VALUES('pole_height_m','2.000')")
        db.execSQL("INSERT INTO project_settings(key,value) VALUES('tip_mode','tip')")
        db.execSQL("INSERT INTO project_settings(key,value) VALUES('next_point','1')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE points ADD COLUMN h_ortho REAL")
            db.execSQL("ALTER TABLE points ADD COLUMN h_acc REAL")
            db.execSQL("ALTER TABLE points ADD COLUMN v_acc REAL")
            db.execSQL("ALTER TABLE points ADD COLUMN acc_src TEXT NOT NULL DEFAULT ''")
        }
    }

    fun pointExists(number: Int): Boolean = readableDatabase.rawQuery("SELECT 1 FROM points WHERE point_number=?", arrayOf(number.toString())).use { it.moveToFirst() }

    fun setting(key: String, defaultValue: String): String = readableDatabase.rawQuery(
        "SELECT value FROM project_settings WHERE key=?", arrayOf(key)
    ).use { if (it.moveToFirst()) it.getString(0) else defaultValue }

    fun setSetting(key: String, value: String) {
        val cv = ContentValues().apply { put("key", key); put("value", value) }
        writableDatabase.insertWithOnConflict("project_settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun nextPointNumber(): Int = setting("next_point", "1").toIntOrNull() ?: 1

    /** Highest line number used by this code, or 1 when there are no points yet. */
    fun lastLine(code: String): Int = readableDatabase.rawQuery("SELECT MAX(line_number) FROM points WHERE code=?", arrayOf(code))
        .use { if (it.moveToFirst() && !it.isNull(0)) maxOf(it.getInt(0), 1) else 1 }

    /** First free positive line number for this feature code (not max+1). */
    fun firstFreeLine(code: String): Int {
        readableDatabase.rawQuery("SELECT DISTINCT line_number FROM points WHERE code=? ORDER BY line_number", arrayOf(code)).use { c ->
            var candidate = 1
            while (c.moveToNext()) {
                val used = c.getInt(0)
                if (used == candidate) candidate++ else if (used > candidate) break
            }
            return candidate
        }
    }

    /** Next (block instance, position in block) for a block code needing n points; incomplete block continues. */
    fun blockSlot(code: String, n: Int): Pair<Int, Int> {
        val last = readableDatabase.rawQuery("SELECT line_number FROM points WHERE code=? ORDER BY point_number DESC LIMIT 1", arrayOf(code))
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }
        if (last == 0) return Pair(1, 1)
        val cnt = readableDatabase.rawQuery("SELECT COUNT(*) FROM points WHERE code=? AND line_number=?", arrayOf(code, last.toString()))
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }
        return if (cnt >= n) Pair(last + 1, 1) else Pair(last, cnt + 1)
    }

    fun savePoint(number: Int, fix: GgaFix, hEll: Double, hTip: Double, tipMode: String,
                  code: String, line: Int, pole: Double, attrsJson: String,
                  hOrtho: Double?, hAcc: Double?, vAcc: Double?, accSrc: String): Long {
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        val cv = ContentValues().apply {
            put("point_number", number); put("latitude", fix.latitude); put("longitude", fix.longitude)
            put("h_ell", hEll); put("h_tip", hTip); put("tip_mode", tipMode)
            put("code", code); put("line_number", line); put("pole_height_m", pole)
            put("fix_quality", fix.fixQuality); put("satellites", fix.satellites)
            if (fix.hdop == null) putNull("hdop") else put("hdop", fix.hdop)
            put("utc", fix.utc); put("saved_at", iso); put("attributes_json", attrsJson)
            if (hOrtho == null) putNull("h_ortho") else put("h_ortho", hOrtho)
            if (hAcc == null) putNull("h_acc") else put("h_acc", hAcc)
            if (vAcc == null) putNull("v_acc") else put("v_acc", vAcc)
            put("acc_src", accSrc)
        }
        val id = writableDatabase.insertOrThrow("points", null, cv)
        setSetting("next_point", (number + 1).toString())
        return id
    }

    fun allPoints(): List<Pt> {
        val out = ArrayList<Pt>()
        readableDatabase.rawQuery("SELECT * FROM points ORDER BY point_number", null).use { while (it.moveToNext()) out += read(it) }
        return out
    }

    fun updatePoint(id: Long, code: String, line: Int, attrsJson: String) {
        val cv = ContentValues().apply { put("code", code); put("line_number", line); put("attributes_json", attrsJson) }
        writableDatabase.update("points", cv, "id=?", arrayOf(id.toString()))
    }

    fun deletePoint(id: Long) { writableDatabase.delete("points", "id=?", arrayOf(id.toString())) }

    private fun read(c: Cursor): Pt {
        fun s(n: String) = c.getString(c.getColumnIndexOrThrow(n))
        fun d(n: String) = c.getDouble(c.getColumnIndexOrThrow(n))
        fun i(n: String) = c.getInt(c.getColumnIndexOrThrow(n))
        fun nd(n: String): Double? { val k = c.getColumnIndexOrThrow(n); return if (c.isNull(k)) null else c.getDouble(k) }
        val hi = c.getColumnIndexOrThrow("hdop")
        return Pt(
            c.getLong(c.getColumnIndexOrThrow("id")), i("point_number"), d("latitude"), d("longitude"),
            d("h_ell"), d("h_tip"), s("tip_mode"), s("code"), i("line_number"), d("pole_height_m"),
            i("fix_quality"), i("satellites"), if (c.isNull(hi)) null else c.getDouble(hi), s("utc"), s("saved_at"), s("attributes_json"),
            nd("h_ortho"), nd("h_acc"), nd("v_acc"), s("acc_src")
        )
    }
}
