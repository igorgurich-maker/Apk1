package com.igor.toposurvey

import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.floor

/**
 * OSGM15 (Malin Head) geoid undulation N, so that H(Malin) = h(ellipsoidal) - N.
 *
 * Reads the Trimble "TNL GRID FILE" (.GGF) distributed by OSi: assets/OSGM15_Malin.GGF
 * (or the same file name in the app external files dir, which takes priority).
 * Layout (little-endian): doubles at 0x30 = latMin, latMax, lonMin, lonMax; at 0x50 = dLat, dLon;
 * int32 at 0x60 = rows, cols; float32 grid from byte 146, row-major, first row = latMin (south), first column = lonMin (west).
 * Layout verified against the supplied file (376 x 326 nodes, 1/75 deg x 0.02 deg).
 */
object Osgm15 {
    private const val FILE = "OSGM15_Malin.GGF"
    private const val DATA_OFFSET = 146
    private var buf: ByteBuffer? = null
    private var lat0 = 0.0; private var lon0 = 0.0; private var dlat = 0.0; private var dlon = 0.0
    private var rows = 0; private var cols = 0
    @Volatile var status: String = "OSGM15: not loaded"; private set
    val isLoaded: Boolean get() = buf != null

    fun init(ctx: Context) {
        try {
            val ext = ctx.getExternalFilesDir(null)?.let { File(it, FILE) }
            val bytes = if (ext != null && ext.isFile) ext.readBytes() else ctx.assets.open(FILE).use { it.readBytes() }
            if (bytes.size < DATA_OFFSET || String(bytes, 2, 13, Charsets.US_ASCII) != "TNL GRID FILE") throw IllegalStateException("not a TNL GGF file")
            val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            lat0 = b.getDouble(0x30); lon0 = b.getDouble(0x40)
            dlat = b.getDouble(0x50); dlon = b.getDouble(0x58)
            rows = b.getInt(0x60); cols = b.getInt(0x64)
            if (rows < 2 || cols < 2 || dlat <= 0 || dlon <= 0 || bytes.size < DATA_OFFSET.toLong() + rows.toLong() * cols * 4) throw IllegalStateException("bad GGF header")
            buf = b
            status = "OSGM15: grid loaded ($rows x $cols)"
        } catch (e: Exception) {
            buf = null
            status = "OSGM15: grid file missing or invalid ($FILE)"
        }
    }

    private fun node(r: Int, c: Int): Double? {
        val v = buf!!.getFloat(DATA_OFFSET + (r * cols + c) * 4).toDouble()
        return if (v.isNaN() || abs(v) < 1.0) null else v   // real N is ~55-60 m here; ~0 means no data
    }

    /** Bilinear undulation in metres, or null when the grid is not loaded or the point is outside it. */
    fun undulation(latDeg: Double, lonDeg: Double): Double? {
        if (buf == null) return null
        val fy = (latDeg - lat0) / dlat
        val fx = (lonDeg - lon0) / dlon
        val r = floor(fy).toInt(); val c = floor(fx).toInt()
        if (fy < 0 || fx < 0 || r >= rows - 1 || c >= cols - 1) return null
        val ty = fy - r; val tx = fx - c
        val a = node(r, c) ?: return null
        val b = node(r, c + 1) ?: return null
        val d = node(r + 1, c) ?: return null
        val e = node(r + 1, c + 1) ?: return null
        return a * (1 - tx) * (1 - ty) + b * tx * (1 - ty) + d * (1 - tx) * ty + e * tx * ty
    }
}
