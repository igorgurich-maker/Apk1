package com.igor.toposurvey

import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor

/**
 * OSGM15 (Malin Head) geoid undulation N, so that H(Malin) = h(ellipsoidal) - N.
 *
 * The grid is NOT bundled. Provide it in NOAA/NGS GTX format as either
 *   app/src/main/assets/osgm15_malin.gtx   or   <app external files dir>/osgm15_malin.gtx
 * GTX: big-endian header (lat0, lon0, dlat, dlon: float64; nrows, ncols: int32), then float32 values row by row, south to north.
 */
object Osgm15 {
    private const val FILE = "osgm15_malin.gtx"
    private var buf: ByteBuffer? = null
    private var lat0 = 0.0; private var lon0 = 0.0; private var dlat = 0.0; private var dlon = 0.0
    private var rows = 0; private var cols = 0
    @Volatile var status: String = "OSGM15: not loaded"; private set
    val isLoaded: Boolean get() = buf != null

    fun init(ctx: Context) {
        try {
            val ext = ctx.getExternalFilesDir(null)?.let { File(it, FILE) }
            val bytes = if (ext != null && ext.isFile) ext.readBytes() else ctx.assets.open(FILE).use { it.readBytes() }
            val b = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
            lat0 = b.getDouble(0); lon0 = b.getDouble(8); dlat = b.getDouble(16); dlon = b.getDouble(24)
            rows = b.getInt(32); cols = b.getInt(36)
            if (rows < 2 || cols < 2 || dlat <= 0 || dlon <= 0 || bytes.size < 40L + rows.toLong() * cols * 4) throw IllegalStateException("bad GTX header")
            buf = b
            status = "OSGM15: grid loaded"
        } catch (e: Exception) {
            buf = null
            status = "OSGM15: grid file missing or invalid ($FILE)"
        }
    }

    private fun node(r: Int, c: Int): Double? {
        val v = buf!!.getFloat(40 + (r * cols + c) * 4).toDouble()
        return if (v < -88.0 && v > -89.0 || v.isNaN()) null else v   // -88.8888 is the GTX no-data value
    }

    /** Bilinear undulation in metres, or null when the grid is not loaded or the point is outside it. */
    fun undulation(latDeg: Double, lonDeg: Double): Double? {
        if (buf == null) return null
        var lon = lonDeg
        if (lon < lon0 - 1e-9) lon += 360.0
        val fy = (latDeg - lat0) / dlat
        val fx = (lon - lon0) / dlon
        val r = floor(fy).toInt(); val c = floor(fx).toInt()
        if (r < 0 || c < 0 || r >= rows - 1 || c >= cols - 1) return null
        val ty = fy - r; val tx = fx - c
        val a = node(r, c) ?: return null
        val b = node(r, c + 1) ?: return null
        val d = node(r + 1, c) ?: return null
        val e = node(r + 1, c + 1) ?: return null
        return a * (1 - tx) * (1 - ty) + b * tx * (1 - ty) + d * (1 - tx) * ty + e * tx * ty
    }
}
