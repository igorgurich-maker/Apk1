package com.igor.toposurvey

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Records every raw receiver line of one Bluetooth connection (a file per connection, written line by line,
 * so nothing is lost if the app is closed). Copy the latest file to Downloads from the menu.
 */
object NmeaLog {
    private var writer: BufferedWriter? = null

    private fun dir(ctx: Context): File = (ctx.getExternalFilesDir(null) ?: ctx.filesDir).also { it.mkdirs() }

    @Synchronized
    fun start(ctx: Context) {
        if (writer != null) return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val f = File(dir(ctx), "nmea_$stamp.txt")
        writer = BufferedWriter(OutputStreamWriter(FileOutputStream(f), Charsets.ISO_8859_1))
    }

    @Synchronized
    fun line(s: String) {
        val w = writer ?: return
        try { w.write(s); w.write("\n"); w.flush() } catch (e: Exception) { }
    }

    @Synchronized
    fun stop() {
        try { writer?.close() } catch (e: Exception) { }
        writer = null
    }

    fun latest(ctx: Context): File? =
        dir(ctx).listFiles { f -> f.name.startsWith("nmea_") }?.maxByOrNull { it.lastModified() }

    /** Copies the latest receiver log to Downloads (same place as the JXL and CSV exports). Returns the file name, or null. */
    fun copyToDownloads(ctx: Context): String? {
        val f = latest(ctx) ?: return null
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
        return f.name
    }
}
