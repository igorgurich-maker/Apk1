package com.igor.toposurvey

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Permanent top GNSS panel. All cells always stay visible; missing data is shown as "--". */
class GnssBar(ctx: Context) : LinearLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val rtk = cell("RTK Status")
    private val sats = cell("Satellites")
    private val hAcc = cell("H Accuracy")
    private val vAcc = cell("V Accuracy")
    private val qualityText = TextView(ctx).apply { textSize = 11f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.LTGRAY); gravity = Gravity.END; setPadding((6 * d).toInt(), 0, 0, 0) }
    private val segments = ArrayList<View>()
    private val off = Color.rgb(60, 70, 78)

    init {
        orientation = VERTICAL
        setBackgroundColor(Color.rgb(32, 42, 50))
        setPadding((8 * d).toInt(), (5 * d).toInt(), (8 * d).toInt(), (5 * d).toInt())
        val top = LinearLayout(ctx).apply { orientation = HORIZONTAL }
        for (c in listOf(rtk, sats, hAcc, vAcc)) top.addView(c.first, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(top)
        val bottom = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, (5 * d).toInt(), 0, 0) }
        bottom.addView(TextView(ctx).apply { text = "Positioning Quality"; textSize = 9f; setTextColor(Color.LTGRAY); setPadding(0, 0, (8 * d).toInt(), 0) })
        val bar = LinearLayout(ctx).apply { orientation = HORIZONTAL }
        for (i in 0 until 4) {
            val s = View(ctx).apply { setBackgroundColor(off) }
            segments += s
            bar.addView(s, LayoutParams(0, (8 * d).toInt(), 1f).apply { rightMargin = (2 * d).toInt() })
        }
        bottom.addView(bar, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(qualityText, LayoutParams((78 * d).toInt(), LayoutParams.WRAP_CONTENT))
        addView(bottom)
    }

    private fun cell(title: String): Pair<LinearLayout, TextView> {
        val v = TextView(context).apply { text = "--"; textSize = 15f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); maxLines = 1 }
        val box = LinearLayout(context).apply {
            orientation = VERTICAL
            addView(TextView(context).apply { text = title; textSize = 9f; setTextColor(Color.LTGRAY); maxLines = 1 })
            addView(v)
        }
        return Pair(box, v)
    }

    private fun set(tv: TextView, text: String, color: Int = Color.WHITE) {
        if (tv.text.toString() != text) tv.text = text
        if (tv.currentTextColor != color) tv.setTextColor(color)
    }

    /** estimate = true prefixes accuracy values with "~" (DOP-based estimate, not receiver-reported). */
    fun update(rtkText: String, rtkColor: Int, satellites: String, h: Double?, v: Double?, hEstimate: Boolean, vEstimate: Boolean, level: Int) {
        set(rtk.second, rtkText, rtkColor)
        set(sats.second, satellites)
        set(hAcc.second, h?.let { (if (hEstimate) "~" else "") + fmt(it) } ?: "--")
        set(vAcc.second, v?.let { (if (vEstimate) "~" else "") + fmt(it) } ?: "--")
        val col = when (level) { 4 -> Color.rgb(66, 211, 146); 3 -> Color.rgb(140, 210, 90); 2 -> Color.rgb(240, 190, 60); 1 -> Color.rgb(235, 110, 70); else -> off }
        for (i in segments.indices) segments[i].setBackgroundColor(if (i < level) col else off)
        qualityText.text = Accuracy.qualityLabel(level)
        qualityText.setTextColor(if (level == 0) Color.LTGRAY else col)
    }

    private fun fmt(m: Double): String = if (m < 1.0) String.format(java.util.Locale.US, "%.3f m", m) else String.format(java.util.Locale.US, "%.2f m", m)
}
