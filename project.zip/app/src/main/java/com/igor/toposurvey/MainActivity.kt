package com.igor.toposurvey

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 20, 24)
    private val panel = Color.rgb(32, 42, 50)
    private val green = Color.rgb(66, 211, 146)
    private val selCol = Color.rgb(36, 94, 76)

    private class Stamped<T>(val v: T, val at: Long)

    private companion object {
        const val PAGE_SIZE = 12            // 4 columns x 3 rows per page
        const val PAGES = 3
        const val QUICK_COUNT = PAGE_SIZE * PAGES
        const val MAX_FIX_AGE_MS = 2000L    // a position older than this is never saved
        const val DISPLAY_STALE_MS = 3000L  // top bar shows "--" after this
        const val HOLD_MS = 15000L          // top bar and map keep the last good values this long; no blink between epochs
        const val REUSE_FIX_MS = 1000L      // MEASURE uses the latest GGA at once if it is at most this old
        const val WAIT_FIX_MS = 4000L       // otherwise wait this long for the next GGA
        const val MAX_POINT = 9999          // Next Point is a 4-digit field
        const val MAX_CODE_LEN = 5
        const val STRIP_H = 46              // height (dp) of -, + and Search in the line strip
        const val LEGACY_COUNT = 24         // quick cells of older versions (2 pages)
        /** Only used to keep older projects unchanged; a new project starts with all quick cells empty. */
        val LEGACY_DEFAULTS = listOf("RE", "CL", "TR", "MH", "FE", "KB", "POLE", "GATE", "S", "LP", "EP", "ST",
            "KT", "WD", "BG", "HE", "PA", "TB", "BB", "IL", "FL", "BU", "BO", "RS")
    }

    private lateinit var store: SurveyStore
    private var features: List<FeatureCode> = emptyList()
    private val byCode = HashMap<String, FeatureCode>()
    private val quick = ArrayList<String>()
    private val quickButtons = ArrayList<Button>()
    private var selectedCode = "RE"
    private var selectedCell = 0           // index (0..23) of the selected quick cell, -1 = code typed in the field
    private var lineNumber = 1
    private var quickPage = 0
    private var tone: ToneGenerator? = null
    private val pageDots = ArrayList<View>()
    private lateinit var mapBox: FrameLayout
    private lateinit var banner: TextView
    private lateinit var confirmBox: LinearLayout
    private lateinit var confirmText: TextView
    private var confirmYes: (() -> Unit)? = null
    private val hideBanner = Runnable { if (::banner.isInitialized) banner.visibility = View.GONE }
    private val hideConfirm = Runnable { if (::confirmBox.isInitialized) confirmBox.visibility = View.GONE }
    private var poleM = 2.0
    private var tipMode = "tip"
    private var projectName = "topo_survey"
    private var pointLabels = true

    private lateinit var rootView: LinearLayout
    private lateinit var pointField: EditText
    private lateinit var codeField: EditText
    private lateinit var lineValue: TextView
    private lateinit var lineLabel: TextView
    private lateinit var lineRow: LinearLayout
    private lateinit var attrRow: LinearLayout
    private lateinit var attrTick: Button
    private val attrGetters = ArrayList<Pair<String, () -> String>>()
    private var attrBuiltFor: Long? = null
    private class PendingAttr(val id: Long, val number: Int, val code: String, val line: Int)
    /** A saved point whose attributes still have to be confirmed with the check button. While set, MEASURE is blocked. */
    private var pending: PendingAttr? = null
    private var blockNote: Pair<String, String>? = null   // (block code, "Block #n closed") shown on the strip until the next point
    private val lineButtons = ArrayList<Button>()
    private var uiUpdating = false
    private var waitingFix = false
    @Volatile private var ggaInterval = 0L
    private lateinit var gnssBar: GnssBar
    private lateinit var coordLine: TextView
    private lateinit var connLine: TextView
    private lateinit var projLabel: TextView
    private lateinit var map: MapView

    @Volatile private var latest: Stamped<GgaFix>? = null
    @Volatile private var gstS: Stamped<GstData>? = null
    @Volatile private var vdopS: Stamped<Double>? = null
    @Volatile private var btState = "BT OFF"
    private val counts = HashMap<String, Int>()
    private val rawLog = ArrayDeque<String>()
    private val gnss = BtGnss({ onLine(it) }, { onBtState(it) })
    @Volatile private var lastGga: String? = null
    @Volatile private var ntripState = "NTRIP OFF"
    @Volatile private var askingNtrip = false
    private val ntrip = NtripClient({ lastGga }, { b, n -> gnss.write(b, n) }, { onNtripState(it) })
    private val ui = Handler(Looper.getMainLooper())
    private var diagText: TextView? = null
    private var diagDialog: AlertDialog? = null

    private val tick = object : Runnable {
        override fun run() {
            updateTop()
            updateDiag()
            ui.postDelayed(this, 500)
        }
    }

    /** The whole UI is English regardless of the phone language. */
    override fun attachBaseContext(base: Context) {
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale.ENGLISH)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        projectName = currentProjectName()
        pointLabels = getSharedPreferences("gurich", MODE_PRIVATE).getBoolean("labels", true)
        store = SurveyStore(this, projectName)
        Osgm15.init(this)
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (e: Exception) { null }
        features = runCatching { FxlReader.load(this) }.getOrDefault(emptyList())
        features.forEach { byCode[it.code] = it }
        loadProject()
        render()
        if (features.isEmpty()) toast("FXL could not be read: feature codes unavailable")
        autoConnect()
        startNtrip()
    }

    override fun onResume() { super.onResume(); refreshAll(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
    override fun onDestroy() { super.onDestroy(); gnss.stop(); ntrip.stop(); NmeaLog.stop(); tone?.release(); tone = null }

    // ---------------- UI ----------------
    // ---------------- projects, exit, receiver log ----------------
    private fun currentProjectName(): String = getSharedPreferences("gurich", MODE_PRIVATE).getString("project", null) ?: "topo_survey"

    /** Reloads per-project state (quick codes, selected code, line, pole, pending attributes) from the open store. */
    private fun loadProject() {
        pending = null; attrBuiltFor = null; blockNote = null
        quick.clear()
        if (store.setting("quick_init", "") != "1") {   // projects made before 0.9.8 keep their old default codes
            val legacy = store.allPoints().isNotEmpty() || (0 until QUICK_COUNT).any { store.setting("quick_$it", "") != "" }
            if (legacy) for (i in 0 until LEGACY_COUNT) if (store.setting("quick_$i", "") == "") store.setSetting("quick_$i", LEGACY_DEFAULTS[i])
            store.setSetting("quick_init", "1")
        }
        for (i in 0 until QUICK_COUNT) quick += store.setting("quick_$i", "")
        selectedCode = store.setting("selected_code", quick[0])
        val savedCell = store.setting("selected_cell", "").toIntOrNull()
        selectedCell = if (selectedCode.isEmpty()) -1 else if (savedCell != null && savedCell in 0 until QUICK_COUNT && quick[savedCell] == selectedCode) savedCell else quick.indexOf(selectedCode)
        lineNumber = rememberedLine()
        loadPole()
        restorePending()
    }

    private fun projectNames(): List<String> = databaseList().filter { it.endsWith(".db") }.map { it.removeSuffix(".db") }.sorted()

    /** Simple names only: letters, digits, _ and -, up to 32 characters. Spaces become _. */
    private fun cleanProjectName(s: String): String? {
        val t = s.trim().replace(Regex("\\s+"), "_")
        return if (t.isNotEmpty() && t.length <= 32 && t.all { it.isLetterOrDigit() || it == '_' || it == '-' }) t else null
    }

    private fun openProject(name: String) {
        store.close()
        store = SurveyStore(this, name)
        projectName = name
        getSharedPreferences("gurich", MODE_PRIVATE).edit().putString("project", name).apply()
        loadProject()
        if (::map.isInitialized) map.resetView()
        refreshAll()
        toast("Project: $name")
    }

    private fun newProjectDialog() {
        val et = EditText(this).apply { hint = "e.g. Site_A"; isSingleLine = true }
        AlertDialog.Builder(this).setTitle("New project").setView(et)
            .setPositiveButton("Create") { _, _ ->
                val n = cleanProjectName(et.text.toString())
                when {
                    n == null -> toast("Use letters, digits, _ or - (max 32 characters)")
                    projectNames().contains(n) -> toast("Project $n already exists. Use Open project")
                    else -> openProject(n)
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun openProjectDialog() {
        val names = projectNames()
        if (names.isEmpty()) { toast("No projects yet. Create one first"); return }
        AlertDialog.Builder(this).setTitle("Open project (now: $projectName)").setItems(names.toTypedArray()) { _, i -> openProject(names[i]) }
            .setNegativeButton("Cancel", null).show()
    }

    /** Sends one text line (+ CR LF) to the receiver over Bluetooth, e.g. to change its output rate. The syntax depends on the receiver. */
    private fun receiverCommandDialog() {
        val prefs = getSharedPreferences("gurich", MODE_PRIVATE)
        val et = EditText(this).apply { setText(prefs.getString("rx_cmd", "") ?: ""); setSingleLine(); hint = "command"; setSelection(text.length) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        box.addView(TextView(this).apply { text = "Sent as typed, followed by CR LF. The reply appears in Menu > Raw NMEA / diagnostics and in the receiver log. The command syntax is receiver-specific (see its manual)."; textSize = 12f })
        box.addView(et)
        AlertDialog.Builder(this).setTitle("Command to receiver").setView(box)
            .setPositiveButton("Send") { _, _ ->
                val c = et.text.toString().trim()
                if (c.isEmpty()) return@setPositiveButton
                if (btState != "BT OK") { toast("Receiver not connected"); return@setPositiveButton }
                prefs.edit().putString("rx_cmd", c).apply()
                val b = (c + "\r\n").toByteArray(Charsets.ISO_8859_1)
                Thread { gnss.write(b, b.size) }.start()
                NmeaLog.line("# TX $c")
                toast("Sent: $c")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun saveNmeaLog() {
        val name = try { NmeaLog.copyToDownloads(this) } catch (e: Exception) { null }
        toast(if (name == null) "No receiver log yet. Connect the receiver first" else "Saved to Downloads: $name")
    }

    private fun togglePointLabels() {
        pointLabels = !pointLabels
        getSharedPreferences("gurich", MODE_PRIVATE).edit().putBoolean("labels", pointLabels).apply()
        if (::map.isInitialized) map.setLabels(pointLabels)
    }

    /** Stops the receiver, NTRIP and timers, removes the app from recents and ends the process. */
    private fun exitApp() {
        gnss.stop(); ntrip.stop(); NmeaLog.stop()
        ui.removeCallbacksAndMessages(null)
        store.close()
        finishAndRemoveTask()
        ui.postDelayed({ android.os.Process.killProcess(android.os.Process.myPid()) }, 300)
    }

    /** Bluetooth state: a receiver log file is written from the moment the receiver connects until it is disconnected. */
    private fun onBtState(s: String) {
        btState = s
        when (s) { "BT OK" -> NmeaLog.start(this); "BT OFF" -> NmeaLog.stop() }
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(bg)
            isFocusable = true; isFocusableInTouchMode = true
        }
        rootView = root
        val header = row().apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("GURICH SURVEY v0.9.10", 18, Color.WHITE, true), weight())
        projLabel = label(projectName, 10, Color.LTGRAY, false).apply { setPadding(0, 0, dp(8), 0); maxLines = 1 }
        header.addView(projLabel)
        header.addView(smallButton("Menu") { showMenu() })
        root.addView(header)

        gnssBar = GnssBar(this)
        root.addView(gnssBar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        // One thin line: X Y Z on the left, link status on the right.
        coordLine = label("X --  Y --  Z --", 11, Color.WHITE, true).apply { typeface = Typeface.MONOSPACE; maxLines = 1 }
        connLine = label("BT OFF · NTRIP OFF", 9, Color.LTGRAY, false).apply { gravity = Gravity.END; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val coordRow = row().apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(3), 0, 0) }
        coordRow.addView(coordLine)
        coordRow.addView(connLine, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        root.addView(coordRow, LinearLayout.LayoutParams(-1, -2))

        map = MapView(this, { byCode[it]?.kind ?: "POINT" }, { blockNeedOf(it) }, { byCode[it]?.color ?: 0xFFB0B8BE.toInt() }, { id -> store.allPoints().firstOrNull { it.id == id }?.let { showPoint(it) } })
        map.setLabels(pointLabels)

        // Next Point + Current Code: narrow editable fields floating over the bottom-right corner of the map.
        pointField = EditText(this).apply {
            id = View.generateViewId()
            setSingleLine(); inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(4))
            textSize = 15f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            background = null; setPadding(0, 0, 0, 0); minHeight = 0; minimumHeight = 0
            imeOptions = EditorInfo.IME_ACTION_NEXT
        }
        codeField = EditText(this).apply {
            id = View.generateViewId()
            setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(MAX_CODE_LEN))
            textSize = 16f; setTextColor(green); setTypeface(typeface, Typeface.BOLD)
            background = null; setPadding(0, 0, 0, 0); minHeight = 0; minimumHeight = 0
            imeOptions = EditorInfo.IME_ACTION_DONE
        }
        pointField.nextFocusForwardId = codeField.id
        codeField.nextFocusForwardId = pointField.id
        // Tab / Next on the point field moves to the code field; each field commits its value when it loses focus.
        pointField.setOnFocusChangeListener { _, has -> if (!has) commitPoint() }
        codeField.setOnFocusChangeListener { _, has -> if (!has) commitCode() }
        pointField.setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_NEXT) { leaveFields(); true } else false }
        codeField.setOnEditorActionListener { _, _, _ -> leaveFields(); true }
        codeField.setOnKeyListener { _, keyCode, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) { leaveFields(); true } else false
        }
        pointField.setOnKeyListener { _, keyCode, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) { leaveFields(); true } else false
        }
        fun floating(title: String, field: EditText) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(2), dp(8), dp(2)); setBackgroundColor(Color.argb(225, 32, 42, 50))
            addView(label(title, 8, Color.LTGRAY, false)); addView(field)
        }
        // Delete-last floats over the top-right corner of the map; Next Point is a cell of the top bar.
        val trash = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_trash); setBackgroundColor(Color.argb(225, 32, 42, 50)); setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { leaveFields(); deleteLastPoint() }
        }
        gnssBar.setNextPointField(pointField)   // Next Point is the fourth cell of the top bar
        mapBox = FrameLayout(this)
        mapBox.addView(map, FrameLayout.LayoutParams(-1, -1))
        mapBox.addView(trash, FrameLayout.LayoutParams(dp(48), dp(42), Gravity.TOP or Gravity.END).apply { topMargin = dp(6); rightMargin = dp(6) })
        banner = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10)); maxWidth = resources.displayMetrics.widthPixels - dp(40)
            visibility = View.GONE; elevation = dp(6).toFloat()
            setOnClickListener { visibility = View.GONE }
        }
        mapBox.addView(banner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(10) })
        confirmText = TextView(this).apply { textSize = 14f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); setPadding(0, 0, dp(10), 0) }
        val yesBtn = Button(this).apply {
            text = "Delete"; isAllCaps = false; setTextColor(Color.WHITE); textSize = 13f; minWidth = 0; minimumWidth = 0
            background = GradientDrawable().apply { setColor(Color.rgb(150, 55, 55)); cornerRadius = dp(6).toFloat() }
            setOnClickListener { confirmBox.visibility = View.GONE; ui.removeCallbacks(hideConfirm); val y = confirmYes; confirmYes = null; y?.invoke() }
        }
        val noBtn = Button(this).apply {
            text = "Cancel"; isAllCaps = false; setTextColor(Color.WHITE); textSize = 13f; minWidth = 0; minimumWidth = 0
            background = GradientDrawable().apply { setColor(Color.rgb(60, 72, 80)); cornerRadius = dp(6).toFloat() }
            setOnClickListener { confirmBox.visibility = View.GONE; ui.removeCallbacks(hideConfirm); confirmYes = null }
        }
        confirmBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(10), dp(8)); background = pill(selCol); visibility = View.GONE; elevation = dp(8).toFloat()
            addView(confirmText)
            addView(yesBtn, LinearLayout.LayoutParams(-2, dp(38)))
            addView(noBtn, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(6) })
        }
        mapBox.addView(confirmBox, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(10) })
        root.addView(mapBox, LinearLayout.LayoutParams(-1, 0, 1.0f).apply { topMargin = dp(6); bottomMargin = dp(4) })

        lineRow = row().apply { gravity = Gravity.CENTER_VERTICAL }
        lineLabel = label("Line", 12, Color.LTGRAY, true)   // not shown: the quick button carries the line number
        lineButtons.clear()
        val isLine = { kindOf(selectedCode) == "LINE" }
        val bMinus = stripButton("−") { if (isLine()) { lineNumber = (lineNumber - 1).coerceAtLeast(1); rememberLine(); refreshValues() } }
        val bPlus = stripButton("+") { if (isLine()) { lineNumber++; rememberLine(); refreshValues() } }
        val bSearch = stripButton("Search") { if (isLine()) { lineNumber = store.firstFreeLine(selectedCode); rememberLine(); refreshValues() } }
        for (b in listOf(bMinus, bPlus, bSearch)) { lineRow.addView(b, LinearLayout.LayoutParams(0, dp(STRIP_H), 1f).apply { setMargins(dp(2), 0, dp(2), 0) }); lineButtons += b }
        lineValue = label("", 12, Color.WHITE, true).apply { gravity = Gravity.CENTER; setBackgroundColor(Color.argb(225, 32, 42, 50)); setPadding(dp(8), 0, dp(8), 0) }   // block: "1 of 3"
        lineRow.addView(lineValue, LinearLayout.LayoutParams(0, dp(STRIP_H), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        attrRow = row().apply { gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE; setBackgroundColor(Color.argb(235, 32, 42, 50)); setPadding(dp(6), dp(4), dp(6), dp(4)) }
        // Line buttons, block progress and attribute fields float over the bottom of the map (the map fills the whole area down to the quick codes).
        val barLp = { FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(4), 0, dp(4), dp(6)) } }
        mapBox.addView(lineRow, barLp())
        mapBox.addView(attrRow, barLp())

        // Page indicator: three short bars centred above the quick codes, the current one is green. Tap = next page.
        val dots = row().apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(4)); setOnClickListener { setQuickPage((quickPage + 1) % PAGES) } }
        pageDots.clear()
        for (i in 0 until PAGES) {
            val d = View(this)
            pageDots += d
            dots.addView(d, LinearLayout.LayoutParams(dp(26), dp(5)).apply { setMargins(dp(5), dp(4), dp(5), dp(4)) })
        }
        root.addView(dots, LinearLayout.LayoutParams(-1, -2))
        val grid = GridLayout(this).apply { columnCount = 4; rowCount = 3 }
        quickButtons.clear()
        for (i in 0 until PAGE_SIZE) {
            val b = Button(this).apply {
                textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); setPadding(0, 0, 0, 0); minWidth = 0; minimumWidth = 0
                setOnClickListener {
                    leaveFields(); val g = quickPage * PAGE_SIZE + i
                    if (quick[g].isEmpty()) editQuick(g) else if (selectedCell == g) measure(false) else selectCell(g)
                }
                setOnLongClickListener { editQuick(quickPage * PAGE_SIZE + i); true }
            }
            quickButtons += b
            val lp = GridLayout.LayoutParams().apply { width = 0; height = dp(40); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(2), dp(2), dp(2), dp(2)) }
            grid.addView(b, lp)
        }
        val swipe = SwipeLayout(this) { dir -> setQuickPage((quickPage + dir).coerceIn(0, PAGES - 1)) }
        swipe.addView(grid)
        root.addView(swipe)
        val measureBtn = Button(this).apply {
            text = "MEASURE / SAVE"; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(selCol)
            setOnClickListener { leaveFields(); measure(false) }
            setOnLongClickListener { leaveFields(); measure(true); true }
        }
        root.addView(measureBtn, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(5) })
        setContentView(root)
        root.requestFocus()
        refreshValues()
    }

    /** Drops focus from the text fields (which commits them) and hides the keyboard. */
    private fun leaveFields() {
        rootView.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(rootView.windowToken, 0)
    }

    private fun commitPoint() {
        if (uiUpdating) return
        val n = pointField.text.toString().toIntOrNull()
        if (n != null && n in 1..MAX_POINT) store.setSetting("next_point", n.toString())
        else toast("Next Point must be 1–$MAX_POINT")
        refreshValues()
    }

    private fun commitCode() {
        if (uiUpdating) return
        val c = codeField.text.toString().trim().uppercase()
        if (c.isEmpty() || c == selectedCode) { refreshValues(); return }
        if (features.isNotEmpty() && !byCode.containsKey(c)) { toast("Code $c not found in FXL"); refreshValues(); return }
        selectCode(c)
    }

    private fun refreshAll() { if (::map.isInitialized) { map.setData(store.allPoints()); refreshValues() } }

    private fun blockNeedOf(code: String) = byCode[code]?.constructionPoints?.takeIf { it > 0 } ?: 1

    private fun refreshValues() {
        uiUpdating = true
        if (!pointField.hasFocus()) pointField.setText(store.nextPointNumber().toString())
        if (!codeField.hasFocus()) codeField.setText(selectedCode)
        uiUpdating = false
        val pend = pending
        lineRow.visibility = if (pend == null && kindOf(selectedCode).let { it == "LINE" || it == "BLOCK" }) View.VISIBLE else View.GONE
        attrRow.visibility = if (pend != null) View.VISIBLE else View.GONE
        if (pend != null && attrBuiltFor != pend.id) buildAttrRow(pend)
        lineValue.setTextColor(Color.WHITE)
        lineValue.textSize = 15f
        lineValue.visibility = if (kindOf(selectedCode) == "BLOCK") View.VISIBLE else View.GONE
        val isBlock = kindOf(selectedCode) == "BLOCK"
        lineButtons.forEach { it.visibility = if (kindOf(selectedCode) == "LINE") View.VISIBLE else View.GONE }
        when (kindOf(selectedCode)) {
            "LINE" -> lineValue.text = ""
            "BLOCK" -> {
                val need = blockNeedOf(selectedCode)
                val slot = store.blockSlot(selectedCode, need)
                val note = blockNote?.takeIf { it.first == selectedCode }?.second
                if (note != null) { lineValue.text = "  $need of $need · closed"; lineValue.setTextColor(green) }
                else lineValue.text = "  ${slot.second - 1} of $need"
            }
            else -> lineValue.text = ""
        }
        for (i in 0 until PAGE_SIZE) {
            val g = quickPage * PAGE_SIZE + i
            val c = quick[g]
            // Line codes show their current line on the button: RE becomes RE1 (updated by Search, + and -).
            val onLine = kindOf(c) == "LINE"
            quickButtons[i].text = if (c.isEmpty()) "+" else if (onLine) "$c${if (g == selectedCell) lineNumber else rememberedLine(g, c)}" else c
            quickButtons[i].setTextColor(if (c.isEmpty()) Color.GRAY else Color.WHITE)
            quickButtons[i].setBackgroundColor(if (g == selectedCell) selCol else panel)
        }
        for (i in pageDots.indices) pageDots[i].background = GradientDrawable().apply { setColor(if (i == quickPage) green else Color.rgb(70, 82, 90)); cornerRadius = dp(3).toFloat() }
    }

    private fun restorePending() {
        val id = store.setting("pending_attr_id", "").toLongOrNull() ?: return
        val p = store.allPoints().firstOrNull { it.id == id }
        val f = p?.let { byCode[it.code] }
        if (p != null && f != null && f.attributes.isNotEmpty()) pending = PendingAttr(p.id, p.number, p.code, p.line)
        else store.setSetting("pending_attr_id", "")
    }

    private fun clearPendingIf(id: Long) {
        if (pending?.id == id) { pending = null; attrBuiltFor = null; store.setSetting("pending_attr_id", "") }
    }

    /** Attribute entry for the point that was just saved. Replaces the line strip until the check button is pressed. */
    private fun buildAttrRow(pd: PendingAttr) {
        attrRow.removeAllViews(); attrGetters.clear()
        val f = byCode[pd.code] ?: return
        attrRow.addView(label("#${pd.number} ${pd.code}", 11, green, true).apply { setPadding(0, 0, dp(6), 0) })
        val inner = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val avail = resources.displayMetrics.widthPixels - dp(20) - dp(52) - dp(70)
        val colW = if (f.attributes.size <= 2) avail / f.attributes.size - dp(4) else dp(120)
        for (a in f.attributes) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(label(a.name, 8, Color.LTGRAY, false).apply { maxLines = 1 })
            val init = a.defaultValue ?: ""
            if (a.type == "Boolean") {
                val cb = CheckBox(this).apply { isChecked = init.equals("true", true) }
                col.addView(cb); attrGetters += (a.name to { if (cb.isChecked) "true" else "false" })
            } else {
                val numeric = a.type == "Double" || a.type == "Integer"
                val et = EditText(this).apply {
                    setText(init); setSingleLine(); textSize = 15f; setTextColor(Color.WHITE)
                    setBackgroundColor(panel); setPadding(dp(6), 0, dp(6), 0)
                    inputType = if (numeric) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED else InputType.TYPE_CLASS_TEXT
                    imeOptions = EditorInfo.IME_ACTION_DONE
                    setOnEditorActionListener { _, _, _ -> confirmAttrs(); true }
                }
                col.addView(et, LinearLayout.LayoutParams(-1, dp(30)))
                attrGetters += (a.name to { if (numeric) et.text.toString().trim().replace(',', '.') else et.text.toString().trim() })
            }
            inner.addView(col, LinearLayout.LayoutParams(colW, -2).apply { rightMargin = dp(4) })
        }
        attrRow.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(inner) }, LinearLayout.LayoutParams(0, -2, 1f))
        attrTick = Button(this).apply {
            text = "✓"; textSize = 18f; minWidth = 0; minimumWidth = 0; setPadding(0, 0, 0, 0)
            setBackgroundColor(selCol); setTextColor(green); setOnClickListener { confirmAttrs() }
        }
        attrRow.addView(attrTick, LinearLayout.LayoutParams(dp(52), dp(40)))
        attrBuiltFor = pd.id
    }

    /** Writes the entered attributes to the saved point and unlocks MEASURE. */
    private fun confirmAttrs() {
        val pd = pending ?: return
        val j = JSONObject(); for ((n, g) in attrGetters) j.put(n, g())
        try {
            store.updatePoint(pd.id, pd.code, pd.line, j.toString())
        } catch (e: Exception) { toast("Could not save attributes: ${e.message}"); return }
        pending = null; attrBuiltFor = null
        store.setSetting("pending_attr_id", "")
        leaveFields()
        toast("Attributes saved for point ${pd.number}")
        refreshAll()
    }

    private fun setQuickPage(p: Int) { quickPage = p; refreshValues() }

    // ---------------- GNSS panel ----------------
    private data class Heights(val hEll: Double, val hTip: Double, val hOrtho: Double?)

    /**
     * Height chain, each correction applied exactly once:
     *  GGA altitude is above the receiver geoid (MSL). Ellipsoidal h = altitude + geoid separation (from the same GGA).
     *  Tip height = h (tip mode) or h - pole (antenna mode). Malin Head Z = tip height - N(OSGM15).
     * Returns null when GGA carries no geoid separation (ellipsoidal height cannot be derived).
     */
    private fun heights(fix: GgaFix): Heights? {
        val sep = fix.geoidSeparationM ?: return null
        val hEll = fix.altitudeM + sep
        val hTip = if (tipMode == "antenna") hEll - poleM else hEll
        val n = Osgm15.undulation(fix.latitude, fix.longitude)
        return Heights(hEll, hTip, n?.let { hTip - it })
    }

    private fun f3(v: Double) = String.format(Locale.US, "%.3f", v)

    // Last good values shown in the top bar and on the map. They change only when a new GGA epoch arrives,
    // so the screen never blinks to "--" between epochs. Cleared only after HOLD_MS without any GGA.
    private var heldFix: GgaFix? = null
    private var heldAcc: AccuracyInfo = AccuracyInfo(null, null, AccuracyInfo.Source.NONE)

    /** 3D accuracy = sqrt(h² + v²), with "estimate" = true when any part is not receiver-reported. Without any vertical value (GGA only) v is assumed 1.5 x h. */
    private fun acc3d(acc: AccuracyInfo): Pair<Double, Boolean>? {
        val h = acc.h ?: return null
        val v = acc.v
        return if (v != null) Pair(kotlin.math.sqrt(h * h + v * v), acc.isEstimate || acc.vEstimate)
        else Pair(h * kotlin.math.sqrt(1 + 1.5 * 1.5), true)
    }

    private fun updateTop() {
        val now = System.currentTimeMillis()
        val s = latest
        if (s != null && now - s.at <= HOLD_MS) {
            val g = gstS?.takeIf { now - it.at <= HOLD_MS }?.v
            val vd = vdopS?.takeIf { now - it.at <= HOLD_MS }?.v
            heldFix = s.v
            heldAcc = Accuracy.resolve(s.v, g, vd)
        } else {
            heldFix = null
            heldAcc = AccuracyInfo(null, null, AccuracyInfo.Source.NONE)
        }
        val fix = heldFix
        val acc = heldAcc
        val grey = Color.LTGRAY
        val (txt, col) = if (fix == null) Pair("--", grey) else when (fix.fixQuality) {
            4 -> Pair("FIX", green)
            5 -> Pair("FLOAT", Color.rgb(240, 190, 60))
            2 -> Pair("DGPS", Color.rgb(235, 150, 70))
            1 -> Pair("SINGLE", Color.rgb(235, 110, 70))
            else -> Pair("NO FIX", Color.rgb(230, 80, 80))
        }
        val a3 = acc3d(acc)
        gnssBar.update(txt, col, fix?.satellites?.toString() ?: "--", a3?.first, a3?.second ?: false, Accuracy.qualityLevel(fix, acc.h))
        if (projLabel.text.toString() != projectName) projLabel.text = projectName

        if (fix != null) {
            val en = Itm.forward(fix.latitude, fix.longitude)
            val h = heights(fix)
            val z = when { h == null -> "n/a"; h.hOrtho != null -> f3(h.hOrtho); else -> "no grid" }
            coordLine.text = "X ${f3(en.first)} Y ${f3(en.second)} Z $z"
        } else coordLine.text = "X --  Y --  Z --"
        connLine.text = "$btState · $ntripState"
        if (::map.isInitialized) map.setCurrent(fix?.latitude, fix?.longitude)
    }

    // ---------------- selection / lines ----------------
    private fun kindOf(c: String) = byCode[c]?.kind ?: "POINT"
    /** Line to continue for a code: the one last used (saved setting), else the highest existing line, else 1. */
    // Every quick cell is its own "theme": two cells with the same code (RE + RE) keep separate line numbers (RE2 / RE3).
    // A code typed in the code field (not tied to a cell) is remembered per code.
    private fun lineKey(cell: Int, code: String) = if (cell >= 0) "line_c$cell" else "line_$code"
    private fun rememberedLine(cell: Int = selectedCell, code: String = selectedCode): Int =
        store.setting(lineKey(cell, code), "").toIntOrNull()?.takeIf { it >= 1 } ?: store.lastLine(code)
    private fun rememberLine() { store.setSetting(lineKey(selectedCell, selectedCode), lineNumber.toString()) }
    private fun selectCell(cell: Int) {
        val code = quick[cell]
        if (blockNote?.first != code) blockNote = null
        selectedCell = cell; selectedCode = code
        store.setSetting("selected_code", code); store.setSetting("selected_cell", cell.toString())
        if (kindOf(code) == "LINE") lineNumber = rememberedLine()
        refreshValues()
    }
    /** Code typed in the code field: if it is the selected cell's code nothing changes, otherwise the first cell with that code, else a cell-less code. */
    private fun selectCode(code: String) {
        val cell = quick.indexOf(code)
        if (cell >= 0) { selectCell(cell); return }
        if (blockNote?.first != code) blockNote = null
        selectedCell = -1; selectedCode = code
        store.setSetting("selected_code", code); store.setSetting("selected_cell", "-1")
        if (kindOf(code) == "LINE") lineNumber = rememberedLine()
        refreshValues()
    }

    private fun loadPole() {
        poleM = store.setting("pole_height_m", "2.000").toDoubleOrNull() ?: 2.0
        tipMode = store.setting("tip_mode", "tip")
    }

    private fun editQuick(i: Int) {
        val et = EditText(this).apply {
            setText(quick[i]); setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(MAX_CODE_LEN))
        }
        AlertDialog.Builder(this).setTitle("Code for cell ${i + 1}").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val c = et.text.toString().trim().uppercase()
                if (c.isEmpty()) {   // empty = clear the cell
                    quick[i] = ""; store.setSetting("quick_$i", ""); store.setSetting("line_c$i", "")
                    if (i == selectedCell) { selectedCell = -1; selectedCode = ""; store.setSetting("selected_code", ""); store.setSetting("selected_cell", "-1") }
                    refreshValues()
                } else if (features.isNotEmpty() && !byCode.containsKey(c)) toast("Code $c not found in FXL")
                else {
                    quick[i] = c; store.setSetting("quick_$i", c); store.setSetting("line_c$i", "")
                    if (i == selectedCell) selectCell(i) else refreshValues()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------------- measuring ----------------
    private fun measure(force: Boolean) {
        if (selectedCode.isEmpty()) { toast("No code selected. Tap an empty quick cell (+) to add one, then tap it"); return }
        pending?.let { toast("Confirm attributes of point ${it.number} with ✓ first"); return }
        if (waitingFix) return
        // At 1 Hz the latest GGA is never older than ~1 s: use it immediately so points can be taken every second.
        val cur = latest
        if (cur != null && System.currentTimeMillis() - cur.at <= REUSE_FIX_MS) { proceed(cur, force); return }
        waitingFix = true
        connLine.text = "Waiting for GGA…"
        waitFix(System.currentTimeMillis(), force)
    }

    /** Waits for the first GGA epoch after the button press instead of saving an old position. */
    private fun waitFix(press: Long, force: Boolean) {
        val s = latest
        val now = System.currentTimeMillis()
        if (s != null && s.at >= press) { waitingFix = false; proceed(s, force); return }
        if (now - press > WAIT_FIX_MS) {
            waitingFix = false
            val age = if (s == null) "none" else "${(now - s.at) / 1000} s ago"
            toast("No new GGA within ${WAIT_FIX_MS / 1000} s (last: $age). Check the i76 link and the GGA output rate")
            return
        }
        ui.postDelayed({ waitFix(press, force) }, 80)
    }

    private fun proceed(s: Stamped<GgaFix>, force: Boolean) {
        val fix = s.v
        val age = System.currentTimeMillis() - s.at
        if (age > MAX_FIX_AGE_MS) { toast("GNSS position is stale ($age ms). Point not saved"); return }
        val next = store.nextPointNumber()
        if (next !in 1..MAX_POINT) { toast("Next Point must be 1–$MAX_POINT"); return }
        if (!force && fix.fixQuality != 4) { toast("No RTK FIX (current fix: ${fix.fixQuality}). Long press MEASURE to save anyway"); return }
        if (fix.geoidSeparationM == null) { toast("GGA has no geoid separation: ellipsoidal height cannot be derived. Point not saved"); return }
        val g = gstS?.takeIf { abs(it.at - s.at) <= 2500 }?.v
        val vd = vdopS?.takeIf { abs(it.at - s.at) <= 2500 }?.v
        val acc = Accuracy.resolve(fix, g, vd)
        save(fix, acc, JSONObject())
    }

    private fun save(fix: GgaFix, acc: AccuracyInfo, attrs: JSONObject) {
        try {
            val h = heights(fix) ?: run { toast("GGA has no geoid separation. Point not saved"); return }
            val n = store.nextPointNumber()
            if (store.pointExists(n)) { toast("Point $n already exists. Change Next Point"); return }
            val kind = kindOf(selectedCode)
            var lineVal = 0
            var closed = false
            if (kind == "LINE") lineVal = lineNumber
            else if (kind == "BLOCK") {
                val need = blockNeedOf(selectedCode)
                val slot = store.blockSlot(selectedCode, need)
                lineVal = slot.first; closed = slot.second >= need
            }
            val newId = store.savePoint(n, fix, h.hEll, h.hTip, tipMode, selectedCode, lineVal, poleM, attrs.toString(), h.hOrtho, acc.h, acc.v, acc.source.name)
            if (kind == "LINE") rememberLine()
            val extra = if (h.hOrtho == null) "\nOSGM15 grid unavailable: Malin Head height not stored" else ""
            if (kind == "BLOCK") blockNote = if (closed) Pair(selectedCode, "Block #$lineVal closed ✓") else null
            val f = byCode[selectedCode]
            val needAttrs = f != null && f.attributes.isNotEmpty()
            if (needAttrs) {   // attributes are entered after the point is measured; MEASURE stays locked until confirmed
                pending = PendingAttr(newId, n, selectedCode, lineVal)
                attrBuiltFor = null
                store.setSetting("pending_attr_id", newId.toString())
            }
            if (closed) beepBlock() else beep()
            toast((if (closed) "Point $n saved. Block #$lineVal closed" else "Point $n saved") + (if (needAttrs) ". Enter attributes and press ✓" else "") + extra)
            refreshAll()
        } catch (e: Exception) { toast("Save error: ${e.message}") }
    }

    /** Dynamic attribute form built from the FXL. Values are NOT carried over from earlier points. */
    private fun attrDialog(f: FeatureCode, existing: Map<String, String>, onOk: (JSONObject) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val getters = ArrayList<Pair<String, () -> String>>()
        for (a in f.attributes) {
            val title = a.name + (a.description?.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: "") + "  [${a.type}]"
            box.addView(TextView(this).apply { text = title; textSize = 12f; setPadding(0, dp(8), 0, 0) })
            val init = existing[a.name] ?: a.defaultValue ?: ""
            if (a.type == "Boolean") {
                val cb = CheckBox(this).apply { isChecked = init.equals("true", true) }
                box.addView(cb); getters += (a.name to { if (cb.isChecked) "true" else "false" })
            } else {
                val numeric = a.type == "Double" || a.type == "Integer"
                val et = EditText(this).apply {
                    setText(init); setSingleLine()
                    inputType = if (numeric) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED else InputType.TYPE_CLASS_TEXT
                }
                box.addView(et); getters += (a.name to { if (numeric) et.text.toString().trim().replace(',', '.') else et.text.toString().trim() })
            }
        }
        AlertDialog.Builder(this).setTitle("${f.code} · ${f.name}").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK") { _, _ -> val j = JSONObject(); for ((n, g) in getters) j.put(n, g()); onOk(j) }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- points ----------------
    private fun showPoint(p: Pt) {
        val en = Itm.forward(p.lat, p.lon)
        val kindTxt = when (kindOf(p.code)) { "LINE" -> "   Line: ${p.line}"; "BLOCK" -> "   Block #${p.line}"; else -> "" }
        val acc = if (p.accSrc.isEmpty()) "n/a" else "H ${p.hAcc?.let { f3(it) } ?: "--"} m / V ${p.vAcc?.let { f3(it) } ?: "--"} m (${if (p.accSrc == "RECEIVER_GST") "receiver GST" else "estimate from DOP"})"
        val msg = "Point ${p.number}\nCode: ${p.code}$kindTxt\n\n" +
            "X (ITM E): ${f3(en.first)}\nY (ITM N): ${f3(en.second)}\n" +
            "Z (Malin Head, OSGM15): ${p.hOrtho?.let { f3(it) } ?: "not stored"}\n\n" +
            "Lat: ${String.format(Locale.US, "%.9f", p.lat)}\nLon: ${String.format(Locale.US, "%.9f", p.lon)}\n" +
            "h ellipsoidal (GGA alt + geoid sep): ${f3(p.hEll)}\nh tip (recorded): ${f3(p.hTip)}\n" +
            "Mode: ${if (p.tipMode == "antenna") "antenna, pole ${f3(p.pole)} subtracted" else "tip, no correction"}\n" +
            "Fix ${p.fixQ} · ${p.sats} sv · HDOP ${p.hdop ?: "-"}\nAccuracy: $acc\nUTC ${p.utc}\n\nAttributes: ${p.attrs}"
        AlertDialog.Builder(this).setTitle("Point ${p.number}").setMessage(msg)
            .setPositiveButton("Close", null)
            .setNeutralButton("Edit") { _, _ -> editPoint(p) }
            .setNegativeButton("Delete") { _, _ ->
                confirm("Delete point ${p.number} (${p.code})?") { store.deletePoint(p.id); clearPendingIf(p.id); blockNote = null; refreshAll() }
            }.show()
    }

    private fun editPoint(p: Pt) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val code = EditText(this).apply {
            setText(p.code); setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(MAX_CODE_LEN))
        }
        val line = EditText(this).apply { setText(p.line.toString()); inputType = InputType.TYPE_CLASS_NUMBER }
        box.addView(TextView(this).apply { text = "Code" }); box.addView(code)
        box.addView(TextView(this).apply { text = "Line number (line codes only)" }); box.addView(line)
        AlertDialog.Builder(this).setTitle("Edit point ${p.number}").setView(box)
            .setPositiveButton("Next") { _, _ ->
                val c = code.text.toString().trim().uppercase()
                val k = kindOf(c)
                val l0 = line.text.toString().toIntOrNull()
                if (c.isEmpty() || (features.isNotEmpty() && !byCode.containsKey(c)) || (k == "LINE" && (l0 == null || l0 < 1))) { toast("Invalid code or line"); return@setPositiveButton }
                val l = when (k) { "LINE" -> l0!!; "BLOCK" -> maxOf(p.line, 1); else -> 0 }
                val old = try { JSONObject(p.attrs) } catch (e: Exception) { JSONObject() }
                val f = byCode[c]
                if (f != null && f.attributes.isNotEmpty()) {
                    val ex = HashMap<String, String>(); for (key in old.keys()) ex[key] = old.optString(key)
                    attrDialog(f, ex) { store.updatePoint(p.id, c, l, it.toString()); refreshAll() }
                } else { store.updatePoint(p.id, c, l, "{}"); refreshAll() }
            }.setNegativeButton("Cancel", null).show()
    }

    /** Short pleasant beep, only when a point has actually been saved. */
    private fun beep() { try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (e: Exception) { } }

    /** Double beep when a block has just been closed. */
    private fun beepBlock() { try { tone?.startTone(ToneGenerator.TONE_PROP_ACK, 250) } catch (e: Exception) { } }

    /** Deletes the most recently saved point at once and gives its number back as Next Point. */
    private fun deleteLastPoint() {
        val last = store.allPoints().maxByOrNull { it.id }
        if (last == null) { toast("No points to delete"); return }
        confirm("Delete point ${last.number} (${last.code})?") {
            store.deletePoint(last.id)
            store.setSetting("next_point", last.number.toString())
            clearPendingIf(last.id)
            blockNote = null   // a block that was just closed is open again and asks for its last point
            refreshAll()
            toast("Point ${last.number} deleted. Next Point is ${last.number} again")
        }
    }

    private fun showPointList() {
        val list = store.allPoints().reversed().take(300)
        if (list.isEmpty()) { toast("No points yet"); return }
        AlertDialog.Builder(this).setTitle("Points (newest first)")
            .setItems(list.map { "#${it.number}   ${it.code}${when (kindOf(it.code)) { "LINE" -> " " + it.line; "BLOCK" -> " block " + it.line; else -> "" }}" }.toTypedArray()) { _, i -> showPoint(list[i]) }
            .setNegativeButton("Close", null).show()
    }

    // ---------------- menu / settings ----------------
    private fun showMenu() {
        leaveFields()
        val items = arrayOf("Connect receiver (Bluetooth)", "Raw NMEA / diagnostics", "Point list", "Pole height & mode", "Export JXL + CSV (to Downloads)", "NTRIP: corrections over internet", "New project", "Open project", "Save receiver log to Downloads", "Send command to receiver", "Point labels: ${if (pointLabels) "ON" else "OFF"}", "Exit")
        AlertDialog.Builder(this).setTitle("Menu").setItems(items) { _, i ->
            when (i) { 0 -> connectMenu(); 1 -> showDiag(); 2 -> showPointList(); 3 -> showPoleSettings(); 4 -> doExport(); 5 -> ntripDialog(); 6 -> newProjectDialog(); 7 -> openProjectDialog(); 8 -> saveNmeaLog(); 9 -> receiverCommandDialog(); 10 -> togglePointLabels(); 11 -> exitApp() }
        }.show()
    }

    private fun showPoleSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(store.setting("pole_height_m", "2.000")) }
        val rg = RadioGroup(this)
        val r1 = RadioButton(this).apply { id = 1; text = "i76 reports the POLE TIP: do not subtract pole height" }
        val r2 = RadioButton(this).apply { id = 2; text = "i76 reports the ANTENNA: subtract pole height (pole must be plumb)" }
        rg.addView(r1); rg.addView(r2)
        rg.check(if (tipMode == "antenna") 2 else 1)
        box.addView(TextView(this).apply { text = "Pole height, m" }); box.addView(et); box.addView(rg)
        AlertDialog.Builder(this).setTitle("Pole").setView(box)
            .setPositiveButton("OK") { _, _ ->
                val h = et.text.toString().replace(',', '.').toDoubleOrNull()
                if (h == null || h < 0 || h > 5) { toast("Invalid height"); return@setPositiveButton }
                store.setSetting("pole_height_m", String.format(Locale.US, "%.3f", h))
                store.setSetting("tip_mode", if (rg.checkedRadioButtonId == 2) "antenna" else "tip")
                loadPole()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun doExport() {
        val pts = store.allPoints()
        if (pts.isEmpty()) { toast("No points to export"); return }
        try {
            val names = Exporter.export(this, pts) { byCode[it]?.kind ?: "POINT" }
            AlertDialog.Builder(this).setTitle("Saved to Downloads").setMessage(names).setPositiveButton("OK", null).show()
        } catch (e: Exception) { toast("Export error: ${e.message}") }
    }

    // ---------------- bluetooth / diagnostics ----------------
    private fun hasBt() = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun connectMenu() {
        if (!hasBt()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 7); return }
        pickDevice()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) pickDevice()
        else if (requestCode == 7) toast("Bluetooth permission is required to connect")
    }

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { toast("Turn Bluetooth on"); return }
        val devs = ad.bondedDevices.toList()
        if (devs.isEmpty()) { toast("Pair the i76 in Android Bluetooth settings first"); return }
        AlertDialog.Builder(this).setTitle("Select receiver")
            .setItems(devs.map { "${it.name} (${it.address})" }.toTypedArray()) { _, i -> store.setSetting("bt_addr", devs[i].address); gnss.start(devs[i]) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun autoConnect() {
        val addr = store.setting("bt_addr", "")
        if (addr.isEmpty() || !hasBt()) return
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
        if (!ad.isEnabled) return
        ad.bondedDevices.firstOrNull { it.address == addr }?.let { gnss.start(it) }
    }

    private fun onLine(line: String) {
        NmeaLog.line(line)
        synchronized(rawLog) { rawLog.addLast(line); while (rawLog.size > 40) rawLog.removeFirst() }
        val type = if (line.startsWith("$") && line.length >= 6) line.substring(1, 6) else line.take(8)
        synchronized(counts) { counts[type] = (counts[type] ?: 0) + 1 }
        val now = System.currentTimeMillis()
        val kind = if (line.startsWith("$") && line.length >= 6) line.substring(3, 6) else ""
        when (kind) {
            "GGA" -> NmeaParser.parseGga(line)?.let { ggaInterval = now - (latest?.at ?: now); latest = Stamped(it, now); lastGga = line }
            "GST" -> NmeaParser.parseGst(line)?.let { gstS = Stamped(it, now) }
            "GSA" -> NmeaParser.parseGsa(line)?.vdop?.let { vdopS = Stamped(it, now) }
        }
    }

    private fun showDiag() {
        val tv = TextView(this).apply { textSize = 10f; typeface = Typeface.MONOSPACE; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        diagText = tv
        diagDialog = AlertDialog.Builder(this).setTitle("Receiver stream").setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Close", null).show()
        updateDiag()
    }

    private fun updateDiag() {
        val d = diagDialog ?: return
        val tv = diagText ?: return
        if (!d.isShowing) return
        val now = System.currentTimeMillis()
        val fix = latest?.takeIf { now - it.at <= DISPLAY_STALE_MS }?.v
        val acc = Accuracy.resolve(fix, gstS?.takeIf { now - it.at <= DISPLAY_STALE_MS }?.v, vdopS?.takeIf { now - it.at <= DISPLAY_STALE_MS }?.v)
        val c = synchronized(counts) { counts.entries.sortedBy { it.key }.joinToString("\n") { "${it.key}: ${it.value}" } }
        val l = synchronized(rawLog) { rawLog.toList().takeLast(25).joinToString("\n") }
        val n = fix?.let { Osgm15.undulation(it.latitude, it.longitude) }
        val sep = fix?.geoidSeparationM
        val geoidLine = if (n == null || sep == null) "OSGM15 N: --" else {
            val diff = n - sep
            "OSGM15 N: ${f3(n)} m | GGA geoid sep: ${f3(sep)} m | diff: ${f3(diff)} m" + if (abs(diff) > 3.0) "  CHECK GRID" else ""
        }
        tv.text = "GGA interval: $ggaInterval ms\nAccuracy source: ${acc.source}\n${Osgm15.status}\n$geoidLine\n\nMessage types:\n$c\n\nLatest lines:\n$l"
    }

    // ---------------- NTRIP ----------------
    // NTRIP settings live in the app (not in a project): the last successful connection is reused at every start.
    private data class NtripCfg(val host: String, val port: Int, val mount: String, val user: String, val pass: String)
    private var ntripCur: NtripCfg? = null
    private var ntripOkPending = false

    private fun loadGood(): NtripCfg? {
        val p = getSharedPreferences("ntrip_good", MODE_PRIVATE)
        val h = p.getString("host", "") ?: ""
        if (h.isEmpty()) return null
        return NtripCfg(h, p.getInt("port", 2101), p.getString("mount", "") ?: "", p.getString("user", "") ?: "", p.getString("pass", "") ?: "")
    }

    private fun saveGood(c: NtripCfg) {
        getSharedPreferences("ntrip_good", MODE_PRIVATE).edit()
            .putString("host", c.host).putInt("port", c.port).putString("mount", c.mount)
            .putString("user", c.user).putString("pass", c.pass).putBoolean("auto", true).apply()
    }

    private fun ntripConnect(c: NtripCfg) {
        ntripCur = c
        ntripOkPending = true
        ntrip.start(c.host, c.port, c.mount, c.user, c.pass)
    }

    /** Every app start: connects with the last successful settings, unless NTRIP was turned off. */
    private fun startNtrip() {
        val g = loadGood() ?: return
        if (getSharedPreferences("ntrip_good", MODE_PRIVATE).getBoolean("auto", true)) ntripConnect(g)
    }

    private fun onNtripState(s: String) {
        ntripState = s
        // a connection counts as successful once the caster answers OK: only then its settings become the saved ones
        if (s.startsWith("NTRIP OK") && ntripOkPending) {
            ntripOkPending = false
            ntripCur?.let { saveGood(it) }
        }
        if (s.startsWith("NTRIP AUTH") && !askingNtrip) runOnUiThread { if (!askingNtrip) ntripDialog(authRetry = true) }
    }

    private fun ntripDialog(authRetry: Boolean = false) {
        askingNtrip = true
        val base = ntripCur ?: loadGood()
        val pre = mapOf(
            "ntrip_host" to (base?.host ?: ""),
            "ntrip_port" to (base?.port ?: 2101).toString(),
            "ntrip_mount" to (base?.mount ?: ""),
            "ntrip_user" to (if (authRetry) "" else base?.user ?: ""),
            "ntrip_pass" to (if (authRetry) "" else base?.pass ?: "")
        )
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        if (authRetry) box.addView(TextView(this).apply {
            text = "The caster refused this login (it may be in use by the other device). Enter the other login and password."
            textSize = 12f; setTextColor(Color.rgb(240, 190, 60))
        })
        fun field(title: String, key: String, def: String, pass: Boolean = false, num: Boolean = false): EditText {
            box.addView(TextView(this).apply { text = title; textSize = 12f; setPadding(0, dp(6), 0, 0) })
            val et = EditText(this).apply {
                setText(pre[key] ?: def); setSingleLine()
                inputType = if (num) InputType.TYPE_CLASS_NUMBER
                    else if (pass) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            }
            box.addView(et); return et
        }
        box.addView(TextView(this).apply { text = "For all constellations (GPS+GLONASS+Galileo+BeiDou) choose an RTCM 3.x MSM mountpoint. Use the button below to list them."; textSize = 11f })
        val host = field("Caster address (host)", "ntrip_host", "")
        val port = field("Port", "ntrip_port", "2101", num = true)
        val mount = field("Mountpoint", "ntrip_mount", "")
        val user = field("Username", "ntrip_user", "")
        val pass = field("Password", "ntrip_pass", "", pass = true)
        box.addView(Button(this).apply {
            text = "List mountpoints from caster"; isAllCaps = false
            setOnClickListener {
                val h = host.text.toString().trim(); val pt = port.text.toString().trim().toIntOrNull() ?: 2101
                val u = user.text.toString().trim(); val pw = pass.text.toString()
                toast("Requesting list…")
                Thread {
                    try {
                        val rows = NtripClient.sourcetable(h, pt, u, pw)
                        runOnUiThread {
                            if (rows.isEmpty()) toast("Caster returned no list")
                            else AlertDialog.Builder(this@MainActivity).setTitle("Mountpoints (RTCM 3 MSM needed)")
                                .setItems(rows.map { r -> "${r.getOrElse(1) { "?" }} · ${r.getOrElse(3) { "" }} ${r.getOrElse(4) { "" }} · ${r.getOrElse(6) { "" }}" }.toTypedArray()) { _, i -> mount.setText(rows[i].getOrElse(1) { "" }) }
                                .show()
                        }
                    } catch (e: Exception) { runOnUiThread { toast("Could not get the list: ${e.javaClass.simpleName}") } }
                }.start()
            }
        })
        AlertDialog.Builder(this).setTitle(if (authRetry) "NTRIP login refused" else "NTRIP (phone needs internet)")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save and connect") { _, _ ->
                askingNtrip = false
                val cfg = NtripCfg(
                    host.text.toString().trim(),
                    port.text.toString().trim().toIntOrNull() ?: 2101,
                    mount.text.toString().trim().removePrefix("/"),
                    user.text.toString().trim(),
                    pass.text.toString()
                )
                if (cfg.host.isEmpty()) { toast("Enter the caster address"); return@setPositiveButton }
                ntripConnect(cfg)
            }
            .setNeutralButton("Turn off") { _, _ ->
                askingNtrip = false
                getSharedPreferences("ntrip_good", MODE_PRIVATE).edit().putBoolean("auto", false).apply()
                ntrip.stop()
            }
            .setNegativeButton("Cancel") { _, _ -> askingNtrip = false }
            .setOnCancelListener { askingNtrip = false }
            .show()
    }

    // ---------------- helpers ----------------
    private fun pill(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(8).toFloat() }

    private fun isProblem(m: String) = listOf("not saved", "No RTK", "No new GGA", "stale", "must be", "not found", "Invalid", "rror", "Could not", "already exists",
        "Confirm attributes", "cannot", "required", "No points", "Turn Bluetooth", "Pair the", "could not", "unavailable").any { m.contains(it) }

    /** In-app message in the style of the MEASURE button (green; dark red for problems). Replaces Android toasts. */
    private fun toast(s: String) {
        if (!::banner.isInitialized) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); return }
        banner.background = pill(if (isProblem(s)) Color.rgb(125, 50, 50) else selCol)
        banner.text = s
        banner.visibility = View.VISIBLE
        ui.removeCallbacks(hideBanner)
        ui.postDelayed(hideBanner, if (s.length > 60) 4500L else 2500L)
    }

    /** Same-style confirmation bar with Delete / Cancel; disappears by itself after 8 s. */
    private fun confirm(text: String, yes: () -> Unit) {
        banner.visibility = View.GONE
        confirmText.text = text
        confirmYes = yes
        confirmBox.visibility = View.VISIBLE
        ui.removeCallbacks(hideConfirm)
        ui.postDelayed(hideConfirm, 8000)
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun cardColumn() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(9), dp(4), dp(9), dp(4)); setBackgroundColor(panel) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun smallButton(s: String, action: () -> Unit) = Button(this).apply { text = s; textSize = 11f; isAllCaps = false; minWidth = dp(42); setPadding(dp(6), 0, dp(6), 0); setOnClickListener { action() } }
    /** Button of the line strip: flat, no Material insets, exactly STRIP_H dp high so it lines up with the trash and Next Point boxes. */
    private fun stripButton(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 17f; isAllCaps = false; setTextColor(Color.WHITE); minWidth = dp(42); minimumWidth = dp(42); minHeight = 0; minimumHeight = 0
        setPadding(dp(8), 0, dp(8), 0)
        background = GradientDrawable().apply { setColor(Color.argb(235, 60, 72, 80)); cornerRadius = dp(6).toFloat() }
        setOnClickListener { action() }
    }
    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
