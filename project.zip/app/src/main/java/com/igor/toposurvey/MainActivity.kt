package com.igor.toposurvey

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 20, 24)
    private val panel = Color.rgb(32, 42, 50)
    private val green = Color.rgb(66, 211, 146)
    private val selCol = Color.rgb(36, 94, 76)

    private lateinit var store: SurveyStore
    private var features: List<FeatureCode> = emptyList()
    private val byCode = HashMap<String, FeatureCode>()
    private val quick = ArrayList<String>()
    private val quickButtons = ArrayList<Button>()
    private var selectedCode = "RE"
    private var lineNumber = 1

    private lateinit var pointValue: TextView
    private lateinit var codeValue: TextView
    private lateinit var lineValue: TextView
    private lateinit var status: TextView
    private lateinit var map: MapView

    @Volatile private var lastFix: GgaFix? = null
    @Volatile private var lastFixAt = 0L
    @Volatile private var btState = "BT OFF"
    private val counts = HashMap<String, Int>()
    private val rawLog = ArrayDeque<String>()
    private val gnss = BtGnss({ onLine(it) }, { btState = it })
    @Volatile private var lastGga: String? = null
    @Volatile private var ntripState = "NTRIP OFF"
    private val ntrip = NtripClient({ lastGga }, { b, n -> gnss.write(b, n) }, { ntripState = it })
    private val ui = Handler(Looper.getMainLooper())
    private var diagText: TextView? = null
    private var diagDialog: AlertDialog? = null

    private val tick = object : Runnable {
        override fun run() {
            updateStatus()
            if (::map.isInitialized) { val f = lastFix; map.setCurrent(f?.latitude, f?.longitude) }
            updateDiag()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SurveyStore(this)
        features = runCatching { FxlReader.load(this) }.getOrDefault(emptyList())
        features.forEach { byCode[it.code] = it }
        val defaults = listOf("RE", "CL", "TR", "MH", "FE", "KB", "POLE", "GATE", "S")
        for (i in 0 until 9) quick += store.setting("quick_$i", defaults[i])
        selectedCode = store.setting("selected_code", quick[0])
        lineNumber = rememberedLine(selectedCode)
        render()
        if (features.isEmpty()) toast("FXL не прочитан: коды недоступны")
        autoConnect()
        startNtrip()
    }

    override fun onResume() { super.onResume(); refreshAll(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
    override fun onDestroy() { super.onDestroy(); gnss.stop(); ntrip.stop() }

    // ---------------- UI ----------------
    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(bg) }
        val header = row().apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("TOPO SURVEY", 18, Color.WHITE, true), weight())
        header.addView(smallButton("МЕНЮ") { showMenu() })
        root.addView(header)
        status = label("BT OFF · RTK -- · IMU n/a", 11, green, true)
        root.addView(status)
        map = MapView(this, { byCode[it]?.kind ?: "POINT" }, { id -> store.allPoints().firstOrNull { it.id == id }?.let { showPoint(it) } })
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1.0f).apply { topMargin = dp(6); bottomMargin = dp(6) })

        val info = row()
        val pointPanel = cardColumn()
        pointPanel.addView(label("NEXT POINT", 10, Color.LTGRAY, false))
        pointValue = label("1", 22, Color.WHITE, true)
        pointPanel.addView(pointValue)
        pointPanel.setOnClickListener { askNextPoint() }
        val codePanel = cardColumn()
        codePanel.addView(label("CURRENT CODE", 10, Color.LTGRAY, false))
        codeValue = label("", 16, green, true)
        codePanel.addView(codeValue)
        info.addView(pointPanel, LinearLayout.LayoutParams(0, dp(54), 1f).apply { rightMargin = dp(4) })
        info.addView(codePanel, LinearLayout.LayoutParams(0, dp(54), 2f).apply { leftMargin = dp(4) })
        root.addView(info)

        val line = row().apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        line.addView(label("LINE", 12, Color.LTGRAY, true))
        lineValue = label("  1  ", 17, Color.WHITE, true)
        line.addView(lineValue, weight())
        line.addView(smallButton("−") { lineNumber = (lineNumber - 1).coerceAtLeast(1); rememberLine(); refreshValues() })
        line.addView(smallButton("+") { lineNumber++; rememberLine(); refreshValues() })
        line.addView(smallButton("SEARCH") { lineNumber = store.firstFreeLine(selectedCode); rememberLine(); refreshValues() })
        root.addView(line)

        root.addView(label("QUICK CODES  (долгий тап = изменить)", 11, Color.LTGRAY, true).apply { setPadding(0, dp(2), 0, dp(3)) })
        val grid = GridLayout(this).apply { columnCount = 3; rowCount = 3 }
        quickButtons.clear()
        for (i in 0 until 9) {
            val b = Button(this).apply {
                textSize = 13f; isAllCaps = false; setTextColor(Color.WHITE)
                setOnClickListener { if (selectedCode == quick[i]) measure(false) else selectCode(quick[i]) }
                setOnLongClickListener { editQuick(i); true }
            }
            quickButtons += b
            val lp = GridLayout.LayoutParams().apply { width = 0; height = dp(42); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(2), dp(2), dp(2), dp(2)) }
            grid.addView(b, lp)
        }
        root.addView(grid)
        val measureBtn = Button(this).apply {
            text = "MEASURE / SAVE"; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(selCol)
            setOnClickListener { measure(false) }
            setOnLongClickListener { measure(true); true }
        }
        root.addView(measureBtn, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(5) })
        setContentView(root)
        refreshValues()
    }

    private fun refreshAll() { if (::map.isInitialized) { map.setData(store.allPoints()); refreshValues() } }

    private fun refreshValues() {
        pointValue.text = store.nextPointNumber().toString()
        val f = byCode[selectedCode]
        codeValue.text = "$selectedCode · ${f?.name ?: "(нет в FXL)"}"
        lineValue.text = "  $lineNumber  "
        for (i in 0 until 9) {
            quickButtons[i].text = quick[i]
            quickButtons[i].setBackgroundColor(if (quick[i] == selectedCode) selCol else panel)
        }
    }

    private fun updateStatus() {
        val f = lastFix
        val fresh = f != null && System.currentTimeMillis() - lastFixAt < 3000
        val rtk = if (f == null || !fresh) "RTK --" else when (f.fixQuality) { 4 -> "RTK FIX"; 5 -> "RTK FLOAT"; 2 -> "DGPS"; 1 -> "SINGLE"; else -> "NO FIX" }
        val extra = if (f != null && fresh) "  ${f.satellites}sv HDOP ${f.hdop?.let { "%.1f".format(it) } ?: "-"}" else ""
        status.text = "$btState · $ntripState\n$rtk$extra · IMU: не определён"
    }

    // ---------------- selection / lines ----------------
    private fun rememberedLine(code: String): Int = store.setting("line_$code", "").toIntOrNull() ?: store.firstFreeLine(code)
    private fun rememberLine() { store.setSetting("line_$selectedCode", lineNumber.toString()) }
    private fun selectCode(code: String) {
        selectedCode = code
        store.setSetting("selected_code", code)
        lineNumber = rememberedLine(code)
        refreshValues()
    }

    private fun editQuick(i: Int) {
        val et = EditText(this).apply { setText(quick[i]); setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS }
        AlertDialog.Builder(this).setTitle("Код для ячейки ${i + 1}").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val c = et.text.toString().trim().uppercase()
                if (c.isEmpty() || (features.isNotEmpty() && !byCode.containsKey(c))) toast("Кода $c нет в FXL")
                else { quick[i] = c; store.setSetting("quick_$i", c); refreshValues() }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun askNextPoint() {
        val et = EditText(this).apply { setText(store.nextPointNumber().toString()); inputType = InputType.TYPE_CLASS_NUMBER }
        AlertDialog.Builder(this).setTitle("Номер следующей точки").setView(et)
            .setPositiveButton("OK") { _, _ -> et.text.toString().toIntOrNull()?.takeIf { it > 0 }?.let { store.setSetting("next_point", it.toString()); refreshValues() } }
            .setNegativeButton("Отмена", null).show()
    }

    // ---------------- measuring ----------------
    private fun measure(force: Boolean) {
        val fix = lastFix
        if (fix == null || System.currentTimeMillis() - lastFixAt > 3000) { toast("Нет свежих данных GNSS. Подключите i76 (МЕНЮ)"); return }
        if (!force && fix.fixQuality != 4) { toast("Нет RTK FIX. Долгое нажатие на MEASURE — сохранить всё равно"); return }
        val f = byCode[selectedCode]
        if (f != null && f.attributes.isNotEmpty()) attrDialog(f, emptyMap()) { save(fix, it) } else save(fix, JSONObject())
    }

    private fun save(fix: GgaFix, attrs: JSONObject) {
        try {
            val pole = store.setting("pole_height_m", "2.000").toDoubleOrNull() ?: 2.0
            val mode = store.setting("tip_mode", "tip")
            val hEll = fix.altitudeM + (fix.geoidSeparationM ?: 0.0)
            val hTip = if (mode == "antenna") hEll - pole else hEll
            val n = store.nextPointNumber()
            store.savePoint(n, fix, hEll, hTip, mode, selectedCode, lineNumber, pole, attrs.toString())
            rememberLine()
            toast("Точка $n сохранена")
            refreshAll()
        } catch (e: Exception) { toast("Ошибка сохранения: ${e.message}") }
    }

    /** Dynamic attribute form built from the FXL. Values are NOT carried over from earlier points. */
    private fun attrDialog(f: FeatureCode, existing: Map<String, String>, onOk: (JSONObject) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val getters = ArrayList<Pair<String, () -> String>>()
        for (a in f.attributes) {
            val title = a.name + (a.description?.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: "") + "  [${a.type}]"
            box.addView(TextView(this).apply { text = title; textSize = 12f; setPadding(0, dp(8), 0, 0) })
            val init = existing[a.name] ?: a.defaultValue ?: ""
            if (a.type == "Boolean") {
                val cb = CheckBox(this).apply { isChecked = init.equals("true", true) }
                box.addView(cb); getters += (a.name to { if (cb.isChecked) "true" else "false" })
            } else {
                val numeric = a.type == "Double" || a.type == "Integer"
                val et = EditText(this).apply {
                    setText(init); setSingleLine()
                    inputType = if (numeric) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED else InputType.TYPE_CLASS_TEXT
                }
                box.addView(et); getters += (a.name to { if (numeric) et.text.toString().trim().replace(',', '.') else et.text.toString().trim() })
            }
        }
        AlertDialog.Builder(this).setTitle("${f.code} · ${f.name}").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK") { _, _ -> val j = JSONObject(); for ((n, g) in getters) j.put(n, g()); onOk(j) }
            .setNegativeButton("Отмена", null).show()
    }

    // ---------------- points ----------------
    private fun showPoint(p: Pt) {
        val en = Itm.forward(p.lat, p.lon)
        val msg = "Точка ${p.number}\nКод: ${p.code}   Линия: ${p.line}\n\n" +
            "ITM E: ${"%.3f".format(en.first)}\nITM N: ${"%.3f".format(en.second)}\n" +
            "Lat: ${"%.9f".format(p.lat)}\nLon: ${"%.9f".format(p.lon)}\n" +
            "h эллипсоид (как принято): ${"%.3f".format(p.hEll)}\nh наконечника (записано): ${"%.3f".format(p.hTip)}\n" +
            "Режим: ${if (p.tipMode == "antenna") "антенна, вычтено ${"%.3f".format(p.pole)}" else "наконечник, без поправки"}\n" +
            "Fix ${p.fixQ} · ${p.sats} sv · HDOP ${p.hdop ?: "-"}\nUTC ${p.utc}\n\nАтрибуты: ${p.attrs}"
        AlertDialog.Builder(this).setTitle("Точка ${p.number}").setMessage(msg)
            .setPositiveButton("Закрыть", null)
            .setNeutralButton("Изменить") { _, _ -> editPoint(p) }
            .setNegativeButton("Удалить") { _, _ ->
                AlertDialog.Builder(this).setMessage("Удалить точку ${p.number}?")
                    .setPositiveButton("Удалить") { _, _ -> store.deletePoint(p.id); refreshAll() }
                    .setNegativeButton("Отмена", null).show()
            }.show()
    }

    private fun editPoint(p: Pt) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val code = EditText(this).apply { setText(p.code); setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS }
        val line = EditText(this).apply { setText(p.line.toString()); inputType = InputType.TYPE_CLASS_NUMBER }
        box.addView(TextView(this).apply { text = "Код" }); box.addView(code)
        box.addView(TextView(this).apply { text = "Номер линии" }); box.addView(line)
        AlertDialog.Builder(this).setTitle("Изменить точку ${p.number}").setView(box)
            .setPositiveButton("Дальше") { _, _ ->
                val c = code.text.toString().trim().uppercase()
                val l = line.text.toString().toIntOrNull()
                if (l == null || l < 1 || c.isEmpty() || (features.isNotEmpty() && !byCode.containsKey(c))) { toast("Неверный код или линия"); return@setPositiveButton }
                val old = try { JSONObject(p.attrs) } catch (e: Exception) { JSONObject() }
                val f = byCode[c]
                if (f != null && f.attributes.isNotEmpty()) {
                    val ex = HashMap<String, String>(); for (k in old.keys()) ex[k] = old.optString(k)
                    attrDialog(f, ex) { store.updatePoint(p.id, c, l, it.toString()); refreshAll() }
                } else { store.updatePoint(p.id, c, l, "{}"); refreshAll() }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showPointList() {
        val list = store.allPoints().reversed().take(300)
        if (list.isEmpty()) { toast("Точек пока нет"); return }
        AlertDialog.Builder(this).setTitle("Точки (новые сверху)")
            .setItems(list.map { "#${it.number}   ${it.code}${if (byCode[it.code]?.kind == "POINT") "" else " " + it.line}" }.toTypedArray()) { _, i -> showPoint(list[i]) }
            .setNegativeButton("Закрыть", null).show()
    }

    // ---------------- menu / settings ----------------
    private fun showMenu() {
        val items = arrayOf("Подключить приёмник (Bluetooth)", "Сырой NMEA / диагностика", "Список точек", "Высота вехи и режим", "Экспорт JXL + CSV (в Загрузки)", "NTRIP: поправки через интернет")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) { 0 -> connectMenu(); 1 -> showDiag(); 2 -> showPointList(); 3 -> showPoleSettings(); 4 -> doExport(); 5 -> ntripDialog() }
        }.show()
    }

    private fun showPoleSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(store.setting("pole_height_m", "2.000")) }
        val rg = RadioGroup(this)
        val r1 = RadioButton(this).apply { id = 1; text = "i76 выдаёт НАКОНЕЧНИК вехи — высоту не вычитать" }
        val r2 = RadioButton(this).apply { id = 2; text = "i76 выдаёт АНТЕННУ — вычесть высоту вехи (веха строго отвесно)" }
        rg.addView(r1); rg.addView(r2)
        rg.check(if (store.setting("tip_mode", "tip") == "antenna") 2 else 1)
        box.addView(TextView(this).apply { text = "Высота вехи, м" }); box.addView(et); box.addView(rg)
        AlertDialog.Builder(this).setTitle("Веха").setView(box)
            .setPositiveButton("OK") { _, _ ->
                val h = et.text.toString().replace(',', '.').toDoubleOrNull()
                if (h == null || h < 0 || h > 5) { toast("Неверная высота"); return@setPositiveButton }
                store.setSetting("pole_height_m", "%.3f".format(java.util.Locale.US, h))
                store.setSetting("tip_mode", if (rg.checkedRadioButtonId == 2) "antenna" else "tip")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun doExport() {
        val pts = store.allPoints()
        if (pts.isEmpty()) { toast("Нет точек для экспорта"); return }
        try {
            val names = Exporter.export(this, pts) { byCode[it]?.kind ?: "POINT" }
            AlertDialog.Builder(this).setTitle("Сохранено в Загрузки").setMessage(names).setPositiveButton("OK", null).show()
        } catch (e: Exception) { toast("Ошибка экспорта: ${e.message}") }
    }

    // ---------------- bluetooth / diagnostics ----------------
    private fun hasBt() = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun connectMenu() {
        if (!hasBt()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 7); return }
        pickDevice()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) pickDevice()
        else if (requestCode == 7) toast("Без разрешения Bluetooth подключение невозможно")
    }

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { toast("Включите Bluetooth"); return }
        val devs = ad.bondedDevices.toList()
        if (devs.isEmpty()) { toast("Сначала спарьте i76 в настройках Bluetooth Android"); return }
        AlertDialog.Builder(this).setTitle("Выберите приёмник")
            .setItems(devs.map { "${it.name} (${it.address})" }.toTypedArray()) { _, i -> store.setSetting("bt_addr", devs[i].address); gnss.start(devs[i]) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun autoConnect() {
        val addr = store.setting("bt_addr", "")
        if (addr.isEmpty() || !hasBt()) return
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
        if (!ad.isEnabled) return
        ad.bondedDevices.firstOrNull { it.address == addr }?.let { gnss.start(it) }
    }

    private fun onLine(line: String) {
        synchronized(rawLog) { rawLog.addLast(line); while (rawLog.size > 40) rawLog.removeFirst() }
        val type = if (line.startsWith("$") && line.length >= 6) line.substring(1, 6) else line.take(8)
        synchronized(counts) { counts[type] = (counts[type] ?: 0) + 1 }
        val fix = NmeaParser.parseGga(line)
        if (fix != null) { lastFix = fix; lastFixAt = System.currentTimeMillis(); lastGga = line }
    }

    private fun showDiag() {
        val tv = TextView(this).apply { textSize = 10f; typeface = Typeface.MONOSPACE; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        diagText = tv
        diagDialog = AlertDialog.Builder(this).setTitle("Поток приёмника").setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Закрыть", null).show()
        updateDiag()
    }

    private fun updateDiag() {
        val d = diagDialog ?: return
        val tv = diagText ?: return
        if (!d.isShowing) return
        val c = synchronized(counts) { counts.entries.sortedBy { it.key }.joinToString("\n") { "${it.key}: ${it.value}" } }
        val l = synchronized(rawLog) { rawLog.toList().takeLast(25).joinToString("\n") }
        tv.text = "Типы сообщений:\n$c\n\nПоследние строки:\n$l"
    }

    // ---------------- NTRIP ----------------
    private fun startNtrip() {
        val h = store.setting("ntrip_host", "")
        if (h.isEmpty()) return
        ntrip.start(h, store.setting("ntrip_port", "2101").toIntOrNull() ?: 2101,
            store.setting("ntrip_mount", ""), store.setting("ntrip_user", ""), store.setting("ntrip_pass", ""))
    }

    private fun ntripDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        fun field(title: String, key: String, def: String, pass: Boolean = false, num: Boolean = false): EditText {
            box.addView(TextView(this).apply { text = title; textSize = 12f; setPadding(0, dp(6), 0, 0) })
            val et = EditText(this).apply {
                setText(store.setting(key, def)); setSingleLine()
                inputType = if (num) InputType.TYPE_CLASS_NUMBER
                    else if (pass) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            }
            box.addView(et); return et
        }
        val host = field("Адрес кастера (host)", "ntrip_host", "")
        val port = field("Порт", "ntrip_port", "2101", num = true)
        val mount = field("Mountpoint", "ntrip_mount", "")
        val user = field("Логин", "ntrip_user", "")
        val pass = field("Пароль", "ntrip_pass", "", pass = true)
        AlertDialog.Builder(this).setTitle("NTRIP (нужен интернет на телефоне)").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Сохранить и подключить") { _, _ ->
                store.setSetting("ntrip_host", host.text.toString().trim())
                store.setSetting("ntrip_port", port.text.toString().trim())
                store.setSetting("ntrip_mount", mount.text.toString().trim().removePrefix("/"))
                store.setSetting("ntrip_user", user.text.toString().trim())
                store.setSetting("ntrip_pass", pass.text.toString())
                startNtrip()
            }
            .setNeutralButton("Выключить") { _, _ -> store.setSetting("ntrip_host", ""); ntrip.stop() }
            .setNegativeButton("Отмена", null).show()
    }

    // ---------------- helpers ----------------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun cardColumn() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(9), dp(4), dp(9), dp(4)); setBackgroundColor(panel) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun smallButton(s: String, action: () -> Unit) = Button(this).apply { text = s; textSize = 11f; minWidth = dp(42); setPadding(dp(6), 0, dp(6), 0); setOnClickListener { action() } }
    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
