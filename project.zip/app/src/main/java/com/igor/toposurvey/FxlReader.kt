package com.igor.toposurvey

import android.content.Context
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream

data class FeatureAttribute(
    val name: String,
    val type: String,
    val description: String?,
    val entryMethod: String?,
    val defaultValue: String?,
    val minimum: String?,
    val maximum: String?,
    val decimals: String?
)

data class FeatureCode(
    val code: String,
    val name: String,
    val kind: String,
    val category: String?,
    val attributes: List<FeatureAttribute>,
    val constructionPoints: Int = 0,
    /** ARGB display colour: the feature colour, or its layer colour when the feature is "by layer". */
    val color: Int = 0xFFB0B8BE.toInt()
)

object FxlReader {
    fun load(context: Context): List<FeatureCode> {
        val bytes = stripBom(context.assets.open("feature_codes.fxl").use { it.readBytes() })
        val colors = runCatching { readColors(java.io.ByteArrayInputStream(bytes)) }.getOrDefault(emptyMap())
        return parse(java.io.ByteArrayInputStream(bytes)).map { f -> colors[f.code]?.let { f.copy(color = it) } ?: f }
    }

    private fun argb(hex: String?): Int? = hex?.trim()?.takeIf { it.length == 8 }?.toLongOrNull(16)?.toInt()

    /** Too-dark colours would vanish on the dark map background. */
    private fun visible(c: Int): Int {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return if (0.299 * r + 0.587 * g + 0.114 * b < 45) 0xFFB0B8BE.toInt() else c or (0xFF shl 24)
    }

    /**
     * code -> colour. A feature Color with alpha FF is used as is; alpha FE (the FXL "by layer" marker) means
     * the colour of the feature's Layer, taken from <LayerDefinition><Name/><Color/>.
     */
    private fun readColors(input: InputStream): Map<String, Int> {
        val parser = Xml.newPullParser()
        parser.setInput(input, "UTF-8")
        val layers = HashMap<String, Int>()
        val feats = ArrayList<Triple<String, Int?, String?>>()
        var inLayer = false
        var layerName = ""
        var layerColor: Int? = null
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "LayerDefinition" -> { inLayer = true; layerName = ""; layerColor = null }
                    "Name" -> if (inLayer) layerName = parser.nextText().trim()
                    "Color" -> if (inLayer) layerColor = argb(parser.nextText())
                    "PointFeatureDefinition", "LineFeatureDefinition", "BlockFeatureDefinition" -> {
                        val code = parser.getAttributeValue(null, "Code") ?: ""
                        val c = argb(parser.getAttributeValue(null, "Color"))
                        val kind = parser.name
                        val layer = parser.getAttributeValue(null, if (kind == "PointFeatureDefinition") "PointLayer" else "Layer")
                            ?: parser.getAttributeValue(null, "Layer")
                        if (code.isNotBlank()) feats += Triple(code, c, layer)
                    }
                }
            } else if (event == XmlPullParser.END_TAG && parser.name == "LayerDefinition") {
                layerColor?.let { layers[layerName] = it }
                inLayer = false
            }
            event = parser.next()
        }
        val out = HashMap<String, Int>()
        for ((code, c, layer) in feats) {
            val resolved = if (c != null && ((c ushr 24) and 255) == 255) c else layer?.let { layers[it] } ?: c
            if (resolved != null) out[code] = visible(resolved)
        }
        return out
    }

    private fun stripBom(b: ByteArray): ByteArray =
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) b.copyOfRange(3, b.size) else b

    fun parse(input: InputStream): List<FeatureCode> {
        val parser = Xml.newPullParser()
        parser.setInput(input, "UTF-8")
        val result = mutableListOf<FeatureCode>()
        var event = parser.eventType
        var inFeature = false
        var featureCode = ""
        var featureName = ""
        var featureKind = ""
        var category: String? = null
        var attributes = mutableListOf<FeatureAttribute>()
        var inAttributes = false
        var construction = 0
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "PointFeatureDefinition", "LineFeatureDefinition", "BlockFeatureDefinition" -> {
                            inFeature = true
                            featureCode = parser.getAttributeValue(null, "Code") ?: ""
                            featureName = parser.getAttributeValue(null, "Name") ?: ""
                            featureKind = parser.name.removeSuffix("FeatureDefinition").uppercase()
                            category = parser.getAttributeValue(null, "Category")
                            attributes = mutableListOf()
                            construction = 0
                        }
                        "Attributes" -> if (inFeature) inAttributes = true
                        "ConstructionType" -> if (inFeature && featureKind == "BLOCK" && construction == 0) construction = parser.nextText().trim().toIntOrNull() ?: 0
                        "StringAttribute", "DoubleAttribute", "IntegerAttribute", "BooleanAttribute", "DateAttribute", "TimeAttribute", "ListAttribute" -> if (inFeature && inAttributes) {
                            val name = parser.getAttributeValue(null, "Name") ?: ""
                            if (name.isNotBlank()) attributes += FeatureAttribute(
                                name = name,
                                type = parser.name.removeSuffix("Attribute"),
                                description = parser.getAttributeValue(null, "Description"),
                                entryMethod = parser.getAttributeValue(null, "EntryMethod"),
                                defaultValue = parser.getAttributeValue(null, "DefaultValue"),
                                minimum = parser.getAttributeValue(null, "MinimumValue"),
                                maximum = parser.getAttributeValue(null, "MaximumValue"),
                                decimals = parser.getAttributeValue(null, "NumberOfDecimals")
                            )
                        }
                    }
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "Attributes" -> inAttributes = false
                    "PointFeatureDefinition", "LineFeatureDefinition", "BlockFeatureDefinition" -> {
                        if (inFeature && featureCode.isNotBlank()) result += FeatureCode(featureCode, featureName, featureKind, category, attributes.toList(), construction)
                        inFeature = false
                    }
                }
            }
            event = parser.next()
        }
        return result.sortedBy { it.code }
    }
}
