package com.igor.toposurvey

import android.content.Context
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream

data class FeatureAttribute(
    val name: String,
    val type: String,
    val description: String?,
    val entryMethod: String?,
    val defaultValue: String?,
    val minimum: String?,
    val maximum: String?,
    val decimals: String?
)

data class FeatureCode(
    val code: String,
    val name: String,
    val kind: String,
    val category: String?,
    val attributes: List<FeatureAttribute>,
    val constructionPoints: Int = 0
)

object FxlReader {
    fun load(context: Context): List<FeatureCode> = context.assets.open("feature_codes.fxl").use {
        parse(java.io.ByteArrayInputStream(stripBom(it.readBytes())))
    }

    private fun stripBom(b: ByteArray): ByteArray =
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) b.copyOfRange(3, b.size) else b

    fun parse(input: InputStream): List<FeatureCode> {
        val parser = Xml.newPullParser()
        parser.setInput(input, "UTF-8")
        val result = mutableListOf<FeatureCode>()
        var event = parser.eventType
        var inFeature = false
        var featureCode = ""
        var featureName = ""
        var featureKind = ""
        var category: String? = null
        var attributes = mutableListOf<FeatureAttribute>()
        var inAttributes = false
        var construction = 0
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "PointFeatureDefinition", "LineFeatureDefinition", "BlockFeatureDefinition" -> {
                            inFeature = true
                            featureCode = parser.getAttributeValue(null, "Code") ?: ""
                            featureName = parser.getAttributeValue(null, "Name") ?: ""
                            featureKind = parser.name.removeSuffix("FeatureDefinition").uppercase()
                            category = parser.getAttributeValue(null, "Category")
                            attributes = mutableListOf()
                            construction = 0
                        }
                        "Attributes" -> if (inFeature) inAttributes = true
                        "ConstructionType" -> if (inFeature && featureKind == "BLOCK" && construction == 0) construction = parser.nextText().trim().toIntOrNull() ?: 0
                        "StringAttribute", "DoubleAttribute", "IntegerAttribute", "BooleanAttribute", "DateAttribute", "TimeAttribute", "ListAttribute" -> if (inFeature && inAttributes) {
                            val name = parser.getAttributeValue(null, "Name") ?: ""
                            if (name.isNotBlank()) attributes += FeatureAttribute(
                                name = name,
                                type = parser.name.removeSuffix("Attribute"),
                                description = parser.getAttributeValue(null, "Description"),
                                entryMethod = parser.getAttributeValue(null, "EntryMethod"),
                                defaultValue = parser.getAttributeValue(null, "DefaultValue"),
                                minimum = parser.getAttributeValue(null, "MinimumValue"),
                                maximum = parser.getAttributeValue(null, "MaximumValue"),
                                decimals = parser.getAttributeValue(null, "NumberOfDecimals")
                            )
                        }
                    }
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "Attributes" -> inAttributes = false
                    "PointFeatureDefinition", "LineFeatureDefinition", "BlockFeatureDefinition" -> {
                        if (inFeature && featureCode.isNotBlank()) result += FeatureCode(featureCode, featureName, featureKind, category, attributes.toList(), construction)
                        inFeature = false
                    }
                }
            }
            event = parser.next()
        }
        return result.sortedBy { it.code }
    }
}
