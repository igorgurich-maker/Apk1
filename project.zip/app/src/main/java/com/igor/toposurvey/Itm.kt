package com.igor.toposurvey

import kotlin.math.*

/** WGS84 lat/lon -> Irish Transverse Mercator (EPSG:2157). Verified against the user's JXL points (sub-mm). */
object Itm {
    private const val A = 6378137.0
    private const val F = 1 / 298.257222101
    private val E2 = 2 * F - F * F
    private val EP2 = E2 / (1 - E2)
    private const val K0 = 0.99982
    private const val FE = 600000.0
    private const val FN = 750000.0
    private const val LON0 = -8.0
    private val LAT0 = Math.toRadians(53.5)

    private fun m(p: Double): Double = A * ((1 - E2 / 4 - 3 * E2 * E2 / 64 - 5 * E2 * E2 * E2 / 256) * p -
        (3 * E2 / 8 + 3 * E2 * E2 / 32 + 45 * E2 * E2 * E2 / 1024) * sin(2 * p) +
        (15 * E2 * E2 / 256 + 45 * E2 * E2 * E2 / 1024) * sin(4 * p) -
        35 * E2 * E2 * E2 / 3072 * sin(6 * p))

    /** Returns (East, North). */
    fun forward(latDeg: Double, lonDeg: Double): Pair<Double, Double> {
        val p = Math.toRadians(latDeg)
        val nu = A / sqrt(1 - E2 * sin(p).pow(2))
        val t = tan(p).pow(2)
        val c = EP2 * cos(p).pow(2)
        val a = Math.toRadians(lonDeg - LON0) * cos(p)
        val e = FE + K0 * nu * (a + (1 - t + c) * a.pow(3) / 6 + (5 - 18 * t + t * t + 72 * c - 58 * EP2) * a.pow(5) / 120)
        val n = FN + K0 * (m(p) - m(LAT0) + nu * tan(p) * (a * a / 2 + (5 - t + 9 * c + 4 * c * c) * a.pow(4) / 24 +
            (61 - 58 * t + t * t + 600 * c - 330 * EP2) * a.pow(6) / 720))
        return Pair(e, n)
    }
}
