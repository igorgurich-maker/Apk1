package com.igor.toposurvey

import android.util.Base64
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** NTRIP v1/v2-compatible client: pulls RTCM from a caster and hands raw bytes to onData; sends GGA every 10 s (VRS). */
class NtripClient(
    private val gga: () -> String?,
    private val onData: (ByteArray, Int) -> Unit,
    private val onState: (String) -> Unit
) {
    @Volatile private var gen = 0
    @Volatile private var socket: Socket? = null

    fun start(host: String, port: Int, mount: String, user: String, pass: String) {
        stop0()
        val my = ++gen
        Thread {
            while (gen == my) {
                try { session(my, host, port, mount, user, pass) } catch (e: Exception) { onState("NTRIP ERR ${e.javaClass.simpleName}") }
                try { socket?.close() } catch (e: Exception) { }
                if (gen == my) { try { Thread.sleep(5000) } catch (e: InterruptedException) { } }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() { stop0(); onState("NTRIP OFF") }
    private fun stop0() { gen++; try { socket?.close() } catch (e: Exception) { } }

    private fun session(my: Int, host: String, port: Int, mount: String, user: String, pass: String) {
        onState("NTRIP CONNECTING")
        val s = Socket()
        socket = s
        s.connect(InetSocketAddress(host, port), 8000)
        s.soTimeout = 3000
        val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
        val req = "GET /$mount HTTP/1.0\r\nUser-Agent: NTRIP TopoSurvey/0.3\r\nAuthorization: Basic $auth\r\nAccept: */*\r\nConnection: close\r\n\r\n"
        s.getOutputStream().write(req.toByteArray())
        val inp = s.getInputStream()
        val first = readLine(inp)
        if (first.startsWith("SOURCETABLE")) { onState("NTRIP ERR mountpoint?"); return }
        if (!first.contains("200")) { onState("NTRIP ERR " + first.take(28)); return }
        if (first.startsWith("HTTP")) { while (readLine(inp).isNotEmpty()) { } }
        onState("NTRIP OK")
        var bytes = 0L
        var lastGga = 0L
        val buf = ByteArray(2048)
        while (gen == my) {
            val now = System.currentTimeMillis()
            if (now - lastGga > 10000) {
                gga()?.let { s.getOutputStream().write((it + "\r\n").toByteArray()); lastGga = now }
            }
            try {
                val n = inp.read(buf)
                if (n < 0) break
                bytes += n
                onData(buf, n)
                onState("NTRIP OK ${bytes / 1024}kB")
            } catch (e: SocketTimeoutException) { }
        }
    }

    private fun readLine(inp: InputStream): String {
        val sb = StringBuilder()
        while (true) {
            val c = inp.read()
            if (c < 0) throw java.io.EOFException()
            if (c == '\n'.code) break
            if (c != '\r'.code) sb.append(c.toChar())
            if (sb.length > 300) break
        }
        return sb.toString()
    }
}
