package com.igor.toposurvey

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.util.UUID

/** Bluetooth SPP reader with automatic reconnect. Delivers raw text lines (NMEA) to onLine. */
class BtGnss(private val onLine: (String) -> Unit, private val onState: (String) -> Unit) {
    @Volatile private var running = false
    @Volatile private var gen = 0
    @Volatile private var socket: BluetoothSocket? = null
    private var thread: Thread? = null

    fun start(device: BluetoothDevice) {
        stop()
        running = true
        val my = ++gen
        thread = Thread {
            while (running && gen == my) {
                try {
                    onState("BT CONNECTING")
                    val s = open(device)
                    socket = s
                    onState("BT OK")
                    val reader = s.inputStream.bufferedReader(Charsets.ISO_8859_1)
                    while (running && gen == my) {
                        val l = reader.readLine() ?: break
                        onLine(l.take(200))
                    }
                } catch (e: Exception) {
                }
                try { socket?.close() } catch (e: Exception) { }
                socket = null
                if (running && gen == my) {
                    onState("BT RETRY")
                    try { Thread.sleep(3000) } catch (e: InterruptedException) { }
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    @SuppressLint("MissingPermission")
    private fun open(device: BluetoothDevice): BluetoothSocket {
        try {
            val s = device.createRfcommSocketToServiceRecord(SPP)
            s.connect()
            return s
        } catch (e: Exception) {
            val s = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType).invoke(device, 1) as BluetoothSocket
            s.connect()
            return s
        }
    }

    fun stop() {
        running = false
        gen++
        try { socket?.close() } catch (e: Exception) { }
        thread?.interrupt()
        onState("BT OFF")
    }

    companion object { val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") }
}
