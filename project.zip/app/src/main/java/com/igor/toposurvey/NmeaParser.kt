package com.igor.toposurvey

/** Parsed GGA fix. Coordinates are WGS84 latitude/longitude; altitudeM is the GGA altitude above the receiver's geoid (MSL). */
data class GgaFix(
    val latitude: Double,
    val longitude: Double,
    val altitudeM: Double,
    val fixQuality: Int,
    val satellites: Int,
    val hdop: Double?,
    val geoidSeparationM: Double?,
    val utc: String
) {
    val hasFix: Boolean get() = fixQuality > 0
    val isRtkFixed: Boolean get() = fixQuality == 4
    val isRtkFloat: Boolean get() = fixQuality == 5
}

/** GST: receiver-reported 1-sigma standard deviations in metres. */
data class GstData(val sigmaLat: Double, val sigmaLon: Double, val sigmaAlt: Double?, val utc: String)

/** GSA: dilution of precision values. */
data class GsaDop(val pdop: Double?, val hdop: Double?, val vdop: Double?)

object NmeaParser {
    /** Returns the comma-separated fields (without '$' and checksum) or null when the checksum is missing/invalid. */
    private fun fields(sentence: String): List<String>? {
        val line = sentence.trim()
        if (!line.startsWith("$")) return null
        val star = line.indexOf('*')
        if (star <= 0 || star + 2 >= line.length) return null
        val expected = line.substring(star + 1, star + 3).toIntOrNull(16) ?: return null
        var checksum = 0
        for (i in 1 until star) checksum = checksum xor line[i].code
        if (checksum != expected) return null
        return line.substring(1, star).split(',')
    }

    /** Returns null for non-GGA sentences, malformed sentences, or invalid checksums. */
    fun parseGga(sentence: String): GgaFix? {
        if (!sentence.contains("GGA")) return null
        val fields = fields(sentence) ?: return null
        if (fields.size < 12 || !fields[0].endsWith("GGA")) return null
        val lat = coordinate(fields[2], fields[3], true) ?: return null
        val lon = coordinate(fields[4], fields[5], false) ?: return null
        val quality = fields[6].toIntOrNull() ?: return null
        val sats = fields[7].toIntOrNull() ?: 0
        val hdop = fields[8].toDoubleOrNull()
        val altitude = fields[9].toDoubleOrNull() ?: return null
        val geoid = fields[11].toDoubleOrNull()
        return GgaFix(lat, lon, altitude, quality, sats, hdop, geoid, fields[1])
    }

    /** $xxGST,time,rms,smajor,sminor,orient,sigmaLat,sigmaLon,sigmaAlt*cs */
    fun parseGst(sentence: String): GstData? {
        if (!sentence.contains("GST")) return null
        val f = fields(sentence) ?: return null
        if (f.size < 9 || !f[0].endsWith("GST")) return null
        val sLat = f[6].toDoubleOrNull() ?: return null
        val sLon = f[7].toDoubleOrNull() ?: return null
        return GstData(sLat, sLon, f[8].toDoubleOrNull(), f[1])
    }

    /** $xxGSA,mode,fixType,sv1..sv12,pdop,hdop,vdop[,systemId]*cs */
    fun parseGsa(sentence: String): GsaDop? {
        if (!sentence.contains("GSA")) return null
        val f = fields(sentence) ?: return null
        if (f.size < 18 || !f[0].endsWith("GSA")) return null
        return GsaDop(f[15].toDoubleOrNull(), f[16].toDoubleOrNull(), f[17].toDoubleOrNull())
    }

    private fun coordinate(raw: String, hemisphere: String, latitude: Boolean): Double? {
        if (raw.isBlank()) return null
        val degreesDigits = if (latitude) 2 else 3
        if (raw.length <= degreesDigits) return null
        val degrees = raw.substring(0, degreesDigits).toDoubleOrNull() ?: return null
        val minutes = raw.substring(degreesDigits).toDoubleOrNull() ?: return null
        if (minutes < 0.0 || minutes >= 60.0) return null
        var value = degrees + minutes / 60.0
        if (hemisphere == "S" || hemisphere == "W") value = -value
        else if (hemisphere != "N" && hemisphere != "E") return null
        return value
    }
}
