package com.igor.toposurvey

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Mini-map in ITM grid. Shows code+line and point number; tap a point to open its card. */
class MapView(ctx: Context, private val kindOf: (String) -> String, private val onTap: (Long) -> Unit) : View(ctx) {
    private var pts: List<Pt> = emptyList()
    private var en: List<Pair<Double, Double>> = emptyList()
    private var curEn: Pair<Double, Double>? = null
    private val d = ctx.resources.displayMetrics.density.toDouble()
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(90, 160, 220); strokeWidth = (2 * d).toFloat(); style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; textSize = (10 * d).toFloat() }
    private val curPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(66, 211, 146); strokeWidth = (2 * d).toFloat(); style = Paint.Style.STROKE }
    private var scr: List<Triple<Long, Float, Float>> = emptyList()

    fun setData(p: List<Pt>) { pts = p; en = p.map { Itm.forward(it.lat, it.lon) }; invalidate() }
    fun setCurrent(lat: Double?, lon: Double?) { curEn = if (lat != null && lon != null) Itm.forward(lat, lon) else null; invalidate() }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.rgb(32, 42, 50))
        val xs = en.map { it.first } + listOfNotNull(curEn?.first)
        val ys = en.map { it.second } + listOfNotNull(curEn?.second)
        if (xs.isEmpty()) { c.drawText("MAP: no points / no GNSS", (12 * d).toFloat(), height / 2f, txt); return }
        val minX = xs.min(); val maxX = xs.max(); val minY = ys.min(); val maxY = ys.max()
        val span = max(max(maxX - minX, maxY - minY), 10.0)
        val scale = (min(width, height) - 72.0 * d) / span
        val cx = (minX + maxX) / 2; val cy = (minY + maxY) / 2
        fun sx(x: Double) = (width / 2.0 + (x - cx) * scale).toFloat()
        fun sy(y: Double) = (height / 2.0 - (y - cy) * scale).toFloat()
        pts.indices.filter { kindOf(pts[it].code) != "POINT" }
            .groupBy { Pair(pts[it].code, pts[it].line) }.values.forEach { g ->
                val s = g.sortedBy { pts[it].number }
                for (k in 1 until s.size) c.drawLine(sx(en[s[k - 1]].first), sy(en[s[k - 1]].second), sx(en[s[k]].first), sy(en[s[k]].second), linePaint)
            }
        val out = ArrayList<Triple<Long, Float, Float>>()
        for (i in pts.indices) {
            val p = pts[i]
            val x = sx(en[i].first); val y = sy(en[i].second)
            c.drawCircle(x, y, (3 * d).toFloat(), dot)
            val lab = when (kindOf(p.code)) { "POINT" -> p.code; "BLOCK" -> "${p.code}·${p.line}"; else -> "${p.code}${p.line}" } + " #" + p.number
            c.drawText(lab, x + (5 * d).toFloat(), y - (4 * d).toFloat(), txt)
            out += Triple(p.id, x, y)
        }
        scr = out
        curEn?.let {
            val x = sx(it.first); val y = sy(it.second); val r = (8 * d).toFloat()
            c.drawCircle(x, y, r, curPaint); c.drawLine(x - r * 1.6f, y, x + r * 1.6f, y, curPaint); c.drawLine(x, y - r * 1.6f, x, y + r * 1.6f, curPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            var best: Long? = null
            var bd = (48 * d) * (48 * d)
            for ((id, x, y) in scr) {
                val dx = (x - e.x).toDouble(); val dy = (y - e.y).toDouble()
                val dd = dx * dx + dy * dy
                if (dd < bd) { bd = dd; best = id }
            }
            best?.let(onTap)
        }
        return true
    }
}
