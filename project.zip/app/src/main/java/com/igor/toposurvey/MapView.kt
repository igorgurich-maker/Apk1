package com.igor.toposurvey

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Mini-map in ITM grid.
 * Points: small yellow dot, optional label "number code" (menu > Point labels).
 * Lines: connected points in the FXL colour.
 * Blocks: 1 point = just the point; 2 points = straight line between them; 3+ points = rectangle (edge p1-p2, width from p3).
 * Gestures: pinch = zoom; two-finger drag = pan; double tap on empty map = zoom reset and centre on the current position.
 */
class MapView(
    ctx: Context,
    private val kindOf: (String) -> String,
    private val blockNeed: (String) -> Int,
    private val colorOf: (String) -> Int,
    private val onTap: (Long) -> Unit
) : View(ctx) {
    private class Shape(val color: Int, val pts: List<Pair<Double, Double>>)

    private var pts: List<Pt> = emptyList()
    private var en: List<Pair<Double, Double>> = emptyList()
    private var curEn: Pair<Double, Double>? = null
    private val d = ctx.resources.displayMetrics.density.toDouble()
    private val dotColor = Color.rgb(255, 235, 59)   // every surveyed point gets a dot of this one colour
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = (2 * d).toFloat(); style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = dotColor; style = Paint.Style.FILL }
    private val msg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; textSize = (11 * d).toFloat() }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = (10 * d).toFloat(); setShadowLayer((2 * d).toFloat(), 0f, 0f, Color.BLACK)
    }
    private val curPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(66, 211, 146); strokeWidth = (2 * d).toFloat(); style = Paint.Style.STROKE }
    private var scr: List<Triple<Long, Float, Float>> = emptyList()
    private var showLabels = true

    // View state in ITM metres: the world point at the screen centre, and zoom relative to fit-to-data.
    private var vcx = Double.NaN
    private var vcy = Double.NaN
    private var zoom = 1.0
    private var fitScale = 1.0        // metres -> pixels at zoom 1, from the last draw
    private var boundsCx = 0.0
    private var boundsCy = 0.0

    private var multiTouch = false
    private var lastMx = 0f
    private var lastMy = 0f

    private val scaleDetector = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(det: ScaleGestureDetector): Boolean {
            if (vcx.isNaN()) return false
            val old = fitScale * zoom
            val newZoom = (zoom * det.scaleFactor).coerceIn(0.2, 60.0)
            val ns = fitScale * newZoom
            // keep the world point under the fingers where it is
            val fx = det.focusX.toDouble() - width / 2.0
            val fy = det.focusY.toDouble() - height / 2.0
            val wx = vcx + fx / old
            val wy = vcy - fy / old
            zoom = newZoom
            vcx = wx - fx / ns
            vcy = wy + fy / ns
            invalidate()
            return true
        }
    })

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (nearest(e.x, e.y) != null) return false   // a double tap on a point is not a reset
            zoom = 1.0
            val cur = curEn
            vcx = cur?.first ?: boundsCx
            vcy = cur?.second ?: boundsCy
            invalidate()
            return true
        }
    })

    fun setData(p: List<Pt>) { pts = p; en = p.map { Itm.forward(it.lat, it.lon) }; invalidate() }
    fun setCurrent(lat: Double?, lon: Double?) {
        val n = if (lat != null && lon != null) Itm.forward(lat, lon) else null
        if (n != curEn) { curEn = n; invalidate() }
    }
    fun setLabels(on: Boolean) { showLabels = on; invalidate() }
    /** Back to fit-to-data zoom and centred on the data (used after switching project). */
    fun resetView() { zoom = 1.0; vcx = Double.NaN; vcy = Double.NaN; invalidate() }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.rgb(24, 32, 38))
        // Shapes (in ITM metres) first, so the fit-to-data extent includes them.
        val rects = ArrayList<Shape>()
        val lines = ArrayList<Shape>()
        pts.indices.filter { kindOf(pts[it].code) != "POINT" }.groupBy { Pair(pts[it].code, pts[it].line) }.forEach { (key, idx) ->
            val s = idx.sortedBy { pts[it].number }.map { en[it] }
            val col = colorOf(key.first)
            if (kindOf(key.first) == "LINE") { if (s.size >= 2) lines += Shape(col, s) }
            else {
                val need = blockNeed(key.first)
                if (need == 2) { if (s.size >= 2) lines += Shape(col, s.take(2)) }
                else if (need >= 3 && s.size >= need) {
                    val ux = s[1].first - s[0].first; val uy = s[1].second - s[0].second
                    val len = kotlin.math.hypot(ux, uy)
                    if (len > 1e-6) {
                        val nx = -uy / len; val ny = ux / len
                        val w = (s[2].first - s[0].first) * nx + (s[2].second - s[0].second) * ny
                        rects += Shape(col, listOf(s[0], s[1], Pair(s[1].first + nx * w, s[1].second + ny * w), Pair(s[0].first + nx * w, s[0].second + ny * w)))
                    }
                }
            }
        }
        val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
        en.forEach { xs += it.first; ys += it.second }
        curEn?.let { xs += it.first; ys += it.second }
        rects.forEach { r -> r.pts.forEach { xs += it.first; ys += it.second } }
        lines.forEach { l -> l.pts.forEach { xs += it.first; ys += it.second } }
        if (xs.isEmpty()) { c.drawText("No points / no GNSS", (12 * d).toFloat(), height / 2f, msg); return }
        val minX = xs.min(); val maxX = xs.max(); val minY = ys.min(); val maxY = ys.max()
        boundsCx = (minX + maxX) / 2; boundsCy = (minY + maxY) / 2
        val span = max(max(maxX - minX, maxY - minY), 10.0)
        fitScale = (min(width, height) - 72.0 * d) / span
        if (vcx.isNaN()) { vcx = boundsCx; vcy = boundsCy }
        val s = fitScale * zoom
        fun sx(x: Double) = (width / 2.0 + (x - vcx) * s).toFloat()
        fun sy(y: Double) = (height / 2.0 - (y - vcy) * s).toFloat()

        for (l in lines) { stroke.color = l.color; for (k in 1 until l.pts.size) c.drawLine(sx(l.pts[k - 1].first), sy(l.pts[k - 1].second), sx(l.pts[k].first), sy(l.pts[k].second), stroke) }
        for (r in rects) {
            val path = Path()
            r.pts.forEachIndexed { i, p -> if (i == 0) path.moveTo(sx(p.first), sy(p.second)) else path.lineTo(sx(p.first), sy(p.second)) }
            path.close(); stroke.color = r.color; c.drawPath(path, stroke)
        }
        val out = ArrayList<Triple<Long, Float, Float>>()
        for (i in pts.indices) {
            val x = sx(en[i].first); val y = sy(en[i].second)
            c.drawCircle(x, y, (2.5 * d).toFloat(), fill)
            if (showLabels) c.drawText("${pts[i].number} ${pts[i].code}", x + (4 * d).toFloat(), y - (4 * d).toFloat(), labelPaint)
            out += Triple(pts[i].id, x, y)
        }
        scr = out
        curEn?.let {
            val x = sx(it.first); val y = sy(it.second); val r = (8 * d).toFloat()
            c.drawCircle(x, y, r, curPaint); c.drawLine(x - r * 1.6f, y, x + r * 1.6f, y, curPaint); c.drawLine(x, y - r * 1.6f, x, y + r * 1.6f, curPaint)
        }
    }

    private fun nearest(x: Float, y: Float): Long? {
        var best: Long? = null
        var bd = (48 * d) * (48 * d)
        for ((id, px, py) in scr) {
            val dx = (px - x).toDouble(); val dy = (py - y).toDouble()
            val dd = dx * dx + dy * dy
            if (dd < bd) { bd = dd; best = id }
        }
        return best
    }

    private fun setMidpoint(e: MotionEvent) {
        if (e.pointerCount >= 2) { lastMx = (e.getX(0) + e.getX(1)) / 2f; lastMy = (e.getY(0) + e.getY(1)) / 2f }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        gestures.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> multiTouch = false
            MotionEvent.ACTION_POINTER_DOWN -> { multiTouch = true; setMidpoint(e) }
            MotionEvent.ACTION_MOVE -> if (e.pointerCount >= 2 && !vcx.isNaN()) {
                // two-finger drag: move the map with the fingers
                val mx = (e.getX(0) + e.getX(1)) / 2f
                val my = (e.getY(0) + e.getY(1)) / 2f
                val s = fitScale * zoom
                vcx -= (mx - lastMx) / s
                vcy += (my - lastMy) / s
                lastMx = mx; lastMy = my
                invalidate()
            }
            MotionEvent.ACTION_UP -> if (!multiTouch) nearest(e.x, e.y)?.let(onTap)
        }
        return true
    }
}
