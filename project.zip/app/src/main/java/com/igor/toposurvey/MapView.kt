package com.igor.toposurvey

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Mini-map in ITM grid. Objects: Point, Line (connected points), Block (rectangle or circle). One colour, no labels.
 * Block needing 3+ points = rectangle (edge p1-p2, width from p3); block needing 2 points = circle (centre p1, radius to p2).
 */
class MapView(
    ctx: Context,
    private val kindOf: (String) -> String,
    private val blockNeed: (String) -> Int,
    private val onTap: (Long) -> Unit
) : View(ctx) {
    private var pts: List<Pt> = emptyList()
    private var en: List<Pair<Double, Double>> = emptyList()
    private var curEn: Pair<Double, Double>? = null
    private val d = ctx.resources.displayMetrics.density.toDouble()
    private val objColor = Color.rgb(90, 160, 220)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = objColor; strokeWidth = (2 * d).toFloat(); style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = objColor; style = Paint.Style.FILL }
    private val msg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; textSize = (11 * d).toFloat() }
    private val curPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(66, 211, 146); strokeWidth = (2 * d).toFloat(); style = Paint.Style.STROKE }
    private var scr: List<Triple<Long, Float, Float>> = emptyList()

    fun setData(p: List<Pt>) { pts = p; en = p.map { Itm.forward(it.lat, it.lon) }; invalidate() }
    fun setCurrent(lat: Double?, lon: Double?) {
        val n = if (lat != null && lon != null) Itm.forward(lat, lon) else null
        if (n != curEn) { curEn = n; invalidate() }
    }

    private class Circle(val c: Pair<Double, Double>, val r: Double)

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.rgb(24, 32, 38))
        // Build block shapes (in ITM metres) first so the view extent can include them.
        val rects = ArrayList<List<Pair<Double, Double>>>()
        val circles = ArrayList<Circle>()
        val lines = ArrayList<List<Pair<Double, Double>>>()
        pts.indices.filter { kindOf(pts[it].code) != "POINT" }.groupBy { Pair(pts[it].code, pts[it].line) }.forEach { (key, idx) ->
            val s = idx.sortedBy { pts[it].number }.map { en[it] }
            if (kindOf(key.first) == "LINE") { if (s.size >= 2) lines += s }
            else {
                val need = blockNeed(key.first)
                if (s.size >= need && need == 2) circles += Circle(s[0], hypot(s[1].first - s[0].first, s[1].second - s[0].second))
                else if (s.size >= need && need >= 3) {
                    val ux = s[1].first - s[0].first; val uy = s[1].second - s[0].second
                    val len = hypot(ux, uy)
                    if (len > 1e-6) {
                        val nx = -uy / len; val ny = ux / len
                        val w = (s[2].first - s[0].first) * nx + (s[2].second - s[0].second) * ny
                        rects += listOf(s[0], s[1], Pair(s[1].first + nx * w, s[1].second + ny * w), Pair(s[0].first + nx * w, s[0].second + ny * w))
                    }
                }
            }
        }
        val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
        en.forEach { xs += it.first; ys += it.second }
        curEn?.let { xs += it.first; ys += it.second }
        rects.forEach { r -> r.forEach { xs += it.first; ys += it.second } }
        circles.forEach { xs += it.c.first - it.r; xs += it.c.first + it.r; ys += it.c.second - it.r; ys += it.c.second + it.r }
        if (xs.isEmpty()) { c.drawText("No points / no GNSS", (12 * d).toFloat(), height / 2f, msg); return }
        val minX = xs.min(); val maxX = xs.max(); val minY = ys.min(); val maxY = ys.max()
        val span = max(max(maxX - minX, maxY - minY), 10.0)
        val scale = (min(width, height) - 72.0 * d) / span
        val cx = (minX + maxX) / 2; val cy = (minY + maxY) / 2
        fun sx(x: Double) = (width / 2.0 + (x - cx) * scale).toFloat()
        fun sy(y: Double) = (height / 2.0 - (y - cy) * scale).toFloat()

        for (l in lines) for (k in 1 until l.size) c.drawLine(sx(l[k - 1].first), sy(l[k - 1].second), sx(l[k].first), sy(l[k].second), stroke)
        for (r in rects) {
            val path = Path()
            r.forEachIndexed { i, p -> if (i == 0) path.moveTo(sx(p.first), sy(p.second)) else path.lineTo(sx(p.first), sy(p.second)) }
            path.close(); c.drawPath(path, stroke)
        }
        for (ci in circles) c.drawCircle(sx(ci.c.first), sy(ci.c.second), (ci.r * scale).toFloat(), stroke)
        val out = ArrayList<Triple<Long, Float, Float>>()
        for (i in pts.indices) {
            val x = sx(en[i].first); val y = sy(en[i].second)
            c.drawCircle(x, y, (3 * d).toFloat(), fill)
            out += Triple(pts[i].id, x, y)
        }
        scr = out
        curEn?.let {
            val x = sx(it.first); val y = sy(it.second); val r = (8 * d).toFloat()
            c.drawCircle(x, y, r, curPaint); c.drawLine(x - r * 1.6f, y, x + r * 1.6f, y, curPaint); c.drawLine(x, y - r * 1.6f, x, y + r * 1.6f, curPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            var best: Long? = null
            var bd = (48 * d) * (48 * d)
            for ((id, x, y) in scr) {
                val dx = (x - e.x).toDouble(); val dy = (y - e.y).toDouble()
                val dd = dx * dx + dy * dy
                if (dd < bd) { bd = dd; best = id }
            }
            best?.let(onTap)
        }
        return true
    }
}
