plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.igor.toposurvey"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.igor.toposurvey"
        minSdk = 29
        targetSdk = 34
        versionCode = 10
        versionName = "0.7.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
